from sqlalchemy import create_engine, delete, select
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column
import subprocess
from datetime import datetime

DB_FILENAME = "key2play.sqlite"
CONNECTION_STRING = f"sqlite:///{DB_FILENAME}"
CONFIG_DEFAULTS = {
    "num_leds_on_strip": 200,
    "num_leds_per_meter": 160,
    "keys_calibrated": False,
    "reinitialize_network_on_boot": True,
    "is_hotspot_active": False,
    "color2x": "#0074DE",  # blue-ish; https://htmlcolorcodes.com/
    "color1x": "#B100B5",  # purple-ish
    "color1": "#33BF00",  # green-ish
    "color2": "#F5EC00",  # yellow-ish
    "color3": "#B81D00",  # red-ish
    "previewDepth": 1,  # for use with the preview depth slider
}


# sqlalchemy schema
class Base(DeclarativeBase):
    pass


class SimpleConfigKV(Base):
    __tablename__ = "simple_config_kv"
    key: Mapped[str] = mapped_column(primary_key=True, nullable=False)
    value: Mapped[str] = mapped_column()

    def __repr__(self) -> str:
        return f"SimpleConfigKV(key={self.key}, value={self.value}"


class MidiLedMap(Base):
    __tablename__ = "midi_led_map"
    midi_note: Mapped[int] = mapped_column(primary_key=True)
    led_index: Mapped[int] = mapped_column()
    r: Mapped[int] = mapped_column()
    g: Mapped[int] = mapped_column()
    b: Mapped[int] = mapped_column()
    time_on: Mapped[int] = mapped_column()
    time_off: Mapped[int] = mapped_column()

    def __repr__(self) -> str:
        return (
            f"MidiLedMap("
            f"midi_note={self.midi_note}, "
            f"led_index={self.led_index}, "
            f"r={self.r}, "
            f"g={self.g}, "
            f"b={self.b}, "
            f"time_on='{self.time_on}', "
            f"time_off='{self.time_off}'"
            f")"
        )
