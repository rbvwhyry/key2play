// console.log("💦🐐🔦learn.js");

//playing 1+ song results in some jank

import { mapNotesLeds, Scale_Patterns, Chord_Patterns, Note_To_Offset } from "./global.js";
import { getRandomRGB, Purple_Color, Red_Color, Color_Black } from "./color.js";
import { turnLedOn, turnLedOff, reliableTurnLedOn, playRainbowAnimation, fillStrip } from "./led.js";

//these get loaded ok with document load (so far); prob because it takes so long to even get to this part of the website manually
const Main_Select = document.getElementById("main-select"); //choices: songs/scales/chords
const Song_Upload = document.getElementById("song-upload"); //uploader for songs
const Song_Search = document.getElementById("song-search"); //dropdown menu to search for songs
const Text_Field = document.getElementById("song-input");
const Dropdown = document.getElementById("song-dropdown");
const Song_Todo = document.getElementById("song-todo"); //choices: visual/heat/auto/play
const Range_Slider = document.getElementById("range-slider"); //partial of a song
const Range_Values = document.getElementById("range-values"); //partial of a song
const Button_Display = document.getElementById("btn-disp");
const Menu_Row = document.getElementById("menu-row"); //contains: menu-note, menu-type, menu-octave; can be used for scales and chords

let selected; //song, scale, or chord
let allSongs = []; //songs we have on our pi
let todo; //visual/heat/auto/play

export function startLearning() {
  console.log("\n💨starting learning...");

  Main_Select.value = '';
  Main_Select.addEventListener("change", () => {
    selected = Main_Select.value; //choices: songs/scales/chords
    console.log(`\n💫selected: ${selected}`); //songs, scales, or chords
    
    Song_Upload.style.display = "none";
    Song_Search.style.display = "none";
    Song_Todo.style.display = "none";
    Range_Slider.style.visibility = "hidden";
    Range_Values.style.display = "none";
    Menu_Row.style.display = "none";
    Button_Display.style.display = "none";

    if (selected === 'songs') learnSongs();
    else learnScalesAndChords();
  });
}

/* 
  order of operation: 
  - upload: get song from device (eg: pc, phone) memory
  - fetchSongs: get all songs from pi, so we can process
  - populateSongDropdown: load all songs so user knows what we have
  - loadLocalMidi: load the song we choose into the memory process
  - getSong: get the song that we just loaded, start playing or whatever
*/
async function learnSongs() { //-> fetchSongs -> populateSongDropdown -> loadLocalMidi -> getSong
  //show song selector and uploader when we selected songs
  Song_Upload.style.display = 'inline-block';
  Song_Search.style.display = 'inline-block';
  Song_Todo.style.display = 'inline-block';
  Range_Slider.style.visibility = "visible";
  Range_Values.style.display = "inline-block";
  Button_Display.style.display = "inline-block";

  allSongs = await fetchSongs(); //get the songs we already have on the pi (allSongs [])
  setSongDropdown(); //sets dropdown menu behavior
  populateSongDropdown(allSongs); //when a song (element of list) is chosen -> define songFull -> getSong
  initSlider();
  listenButton();
}

  async function fetchSongs() {
    const Response = await fetch("/api/get_songs");
    const Data = Response.json();

    return Data;
  }

  function setSongDropdown() {
    Text_Field.addEventListener("input", () => {
      if (Text_Field.value.trim() === "") populateSongDropdown(allSongs);
      else filterSongs();
    });

    // Close dropdown when clicking outside
    document.addEventListener("click", e => {
      if (!e.target.closest(".dropdown")) Dropdown.style.display = "none";
    });
  }

    function filterSongs() {
      const Input = document.getElementById("song-input").value.toLowerCase();
      const Filtered = allSongs.filter(song => song.toLowerCase().includes(Input));
      populateSongDropdown(Filtered);
    }

    let songFull, songChronoMerged, songEventCounts;
    let cropChronoMerged, cropEventCounts;
    function populateSongDropdown(allSongs) {
      Dropdown.innerHTML = ""; //clear

      allSongs.forEach(Song => {
        const Line = document.createElement("div");
        Line.textContent = Song;
        Line.onclick = async () => { //if any song is selected: proceed to process it and eventually turn on the leds
          console.log(`🎵 Selected: ${Song}`);
          Text_Field.value = Song;
          Dropdown.style.display = "none";

          await loadLocalMidi(Song); //find and load song before getting it from server
          songFull = await getSong(); //get that song from server, make it (array) available for analysis
          console.log("songFull: ", songFull);

          songChronoMerged = extractChronologicalNoteGroups(songFull);
          console.log("🦏songChronoMerged: ", songChronoMerged);

          // songEventCounts = countMidiNotes(songChronoMerged); //get count for future instances (a note, a chord, is 1 instance)
          // console.log("songEventCounts: ", songEventCounts);

          // listenTodo(Chrono, Counts); //what to do with the song we just selected?
          // await listenTodo(Chrono, Counts);
        };
        Dropdown.appendChild(Line);
      });

      Dropdown.style.display = "block";
    }

      async function loadLocalMidi(filename) {
        try {
          const response = await fetch("/api/load_local_midi", {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `filename=${encodeURIComponent(filename)}`
          });

          if (!response.ok) throw new Error(`HTTP ${response.status}`);

          const result = await response.json(); // optional, if backend returns JSON
          console.log("✅ MIDI loaded:", result);
          return result;
        } catch (err) {
          console.error("❌ Failed to load MIDI:", err);
          return null;
        }
      }

      async function getSong() {
        try {
          const Response = await fetch("/api/get_current_song");
          if (!Response.ok) throw new Error(`HTTP error ${Response.status}`);

          const Data = await Response.json();
          return Data;
        } catch (err) {
          console.error("Failed to fetch song:", err);
          return null;
        }
      }

      function extractChronologicalNoteGroups(Full_Song) {
        const Active_Notes = {};
        const Note_Events = [];
        let currentTime = 0;

        // First, build flat note event objects with start/end
        for (const Event of Full_Song) {
          currentTime += Event.time;

          if (Event.type === "note_on") {
            const Key = `${Event.note}_${Event.channel}`;

            if (Event.velocity > 0) {
              // Start note
              Active_Notes[Key] = {
                note: Event.note,
                velocity: Event.velocity,
                start: currentTime
              };
            } else if (Active_Notes[Key]) {
              // End note (note_on with velocity 0)
              const noteObj = Active_Notes[Key];
              noteObj.end = currentTime;
              Note_Events.push(noteObj);
              delete Active_Notes[Key];
            }
          }

          if (Event.type === "note_off") {
            const key = `${Event.note}_${Event.channel}`;
            if (Active_Notes[key]) {
              const noteObj = Active_Notes[key];
              noteObj.end = currentTime;
              Note_Events.push(noteObj);
              delete Active_Notes[key];
            }
          }
        }

        // Group notes by identical start/end
        const Group_Map = new Map();

        for (const Note of Note_Events) {
          const Key = `${Note.start}_${Note.end}`;
          if (!Group_Map.has(Key)) {
            Group_Map.set(Key, []);
          }
          Group_Map.get(Key).push(Note);
        }

        // Build final array
        const Result = [];
        for (const [Key, Group] of Group_Map.entries()) {
          const [Start, End] = Key.split("_").map(Number);
          Result.push({
            Start,
            End,
            notes: Group.map(n => n.note),
            velocity: Group.map(n => n.velocity)
          });
        }

        // Sort by start time
        Result.sort((a, b) => a.Start - b.Start);
        return Result;
      }

    let startPercent = 0;
    let endPercent = 100;
    function initSlider() {
      noUiSlider.create(Range_Slider, { //initialize dual-thumb slider
        start: [0, 100],
        connect: true,
        step: 1,
        range: {
          min: 0,
          max: 100
        },
        tooltips: true,
        format: {
          to: value => Math.round(value),
          from: value => parseInt(value)
        }
      });

      Range_Slider.noUiSlider.on('update', function(values) { //listen for changes
        //store & use values
        startPercent = parseInt(values[0]);
        endPercent = parseInt(values[1]);

        document.getElementById('start-val').textContent = startPercent;
        document.getElementById('end-val').textContent = endPercent;
      });
    }

    function listenButton() {
      Button_Display.addEventListener("click", async () => {
        console.log(`🟨clicked!`);

        cancelLightShow(); // 🛑 interrupt any ongoing light show

        //remember: any mode above will let user choose how many future steps to set
        await fillStrip(Color_Black); //turn off strip

        //get values
        todo = Song_Todo.value; //choices: visual/heat/auto/play
        console.log(`🌹todo: ${todo}`);

        cropChronoMerged = cropChrono(songChronoMerged);
        console.log("🐥cropChronoMerged: ", cropChronoMerged);

        cropEventCounts = countMidiNotes(cropChronoMerged);
        console.log("cropEventCounts: ", cropEventCounts);

        //process values
        if (todo === 'visual') { //basic turn on: visual map
          const Leds_Obj = getSongLights(cropEventCounts);
          turnLedOn(Leds_Obj); //remember to turn off as well, before another song turns on
        } else if (todo === 'heat') { //colorized: heat map
          const Leds_Obj = getSongHeatmap(cropEventCounts);
          turnLedOn(Leds_Obj); //remember to turn off as well, before another song turns on
        } else if (todo === 'auto') { //timed: show how the song is played true to timing
          playLightShow(cropChronoMerged); //timing needs to probably be slower <----------
        } else if (todo === 'play') { //wait: lets player play
          const Merged_Chrono = mergeNearbyEvents(cropChronoMerged, 33); //33ms threshold; the higher the threshold, the more notes will stick together to be chords; @22 - some chords from claire de lune still appeared separate
          playInteractive(Merged_Chrono);
          //end rainbow not yet cancelable <------------
        }
      });  
    }

      export function cancelLightShow() {
        for (const id of lightShowTimeouts) {
          clearTimeout(id);
        }
        lightShowTimeouts = [];
        console.log("🛑 Light show cancelled.");
      }

      function cropChrono(chrono) {
        const totalEvents = chrono.length;
        const startIndex = Math.floor((startPercent / 100) * totalEvents);
        const endIndex = Math.floor((endPercent / 100) * totalEvents);

        return chrono.slice(startIndex, endIndex);
      }

      function countMidiNotes(chronoArray) {
        const counts = {};

        for (const event of chronoArray) {
          for (const note of event.notes) {
            counts[note] = (counts[note] || 0) + 1;
          }
        }

        return counts;
      }

      function getSongLights(Freq_Map) {
        const Result = [];

        for (const Key of Object.keys(Freq_Map)) {
          const Midi_Note = Number(Key);
          const Index_Led = getLedIndexFromMidi(Midi_Note);
          Result.push([Index_Led, getRandomRGB()]);
        }

        return Result;
      }

      function getSongHeatmap(Freq_Map) {
        const Result = [];

        // Step 1: Get array of frequency values
        const frequencies = Object.values(Freq_Map); //array of just the values
        const minFreq = Math.min(...frequencies);
        const maxFreq = Math.max(...frequencies);

        // Step 2: Loop through each MIDI note in the map
        for (const Key of Object.keys(Freq_Map)) {
          const Midi_Note = Number(Key);
          const freq = Freq_Map[Key];

          //step 3: Convert MIDI note to LED index
          const Index_Led = getLedIndexFromMidi(Midi_Note);

          // Step 4: Normalize frequency to a value between 0 and 1
          // If all frequencies are the same (ex: all notes have the same freq; avoid divide-by-zero), use 0.5 (midpoint color)
          const t = (maxFreq === minFreq)
            ? 0.5
            : (freq - minFreq) / (maxFreq - minFreq);

          // Step 5: Create gradient color from red (low) to green (high)
          const r = Math.round(255 * (1 - t)); // fades from 255 → 0
          const g = Math.round(255 * t);       // fades from 0 → 255
          const b = 0;                          // no blue in this spectrum

          // Step 6: Store the LED index and its corresponding color
          Result.push([Index_Led, {r:r, g:g, b:b}]);
        }

        return Result;
      }

        function getLedIndexFromMidi(midiNote) {
          const entry = mapNotesLeds.find(obj => obj.midi_note === midiNote);
          return entry ? entry.led_index : null;  // or undefined
        }

      let lightShowTimeouts = []; // ⬅️ store global references to cancel later
      export function playLightShow(chrono) {
        // Clear any previous light show before starting a new one
        cancelLightShow();

        for (const event of chrono) {
          const { start, end, notes, velocity } = event;

          for (let i = 0; i < notes.length; i++) {
            const midiNote = notes[i];
            const vel = velocity[i];

            const ledEntry = mapNotesLeds.find(e => e.midi_note === midiNote);
            if (!ledEntry) {
              console.warn(`⛔ No LED mapping found for MIDI ${midiNote}`);
              continue;
            }

            const ledIndex = ledEntry.led_index;
            const color = getRandomRGB();

            // Schedule ON
            const onTimeout = setTimeout(() => {
              turnLedOn([[ledIndex, color]]);
            }, start);
            lightShowTimeouts.push(onTimeout);

            // Schedule OFF
            const offTimeout = setTimeout(() => {
              turnLedOff([ledIndex]);
            }, end);
            lightShowTimeouts.push(offTimeout);
          }
        }

        console.log(`🎵 Scheduled ${chrono.length} visual events.`);
      }

      function mergeNearbyEvents(chrono, threshold) {
        if (!Array.isArray(chrono) || chrono.length === 0) return [];

        const merged = [];
        let current = { ...chrono[0], notes: [...chrono[0].notes], velocity: [...(chrono[0].velocity || [])] };

        for (let i = 1; i < chrono.length; i++) {
          const next = chrono[i];

          const delta = next.start - current.start;
          if (delta <= threshold) {
            // Merge notes
            current.notes.push(...next.notes);
            // Merge velocities if they exist
            if (next.velocity) current.velocity.push(...next.velocity);
            // Update the end time if needed
            current.end = Math.max(current.end, next.end);
          } else {
            // Push current and start a new one
            merged.push(current);
            current = { ...next, notes: [...next.notes], velocity: [...(next.velocity || [])] };
          }
        }

        merged.push(current); // Final one
        return merged;
      }

      async function playInteractive(Merged_Chrono) {
        console.log(`🎵 Starting interactive mode: ${startPercent}% to ${endPercent}%`);

        const Count_Total_Events = Merged_Chrono.length;

        // Convert percentages to absolute index positions
        const startIdx = Math.floor((startPercent / 100) * Count_Total_Events);
        const endIdx = Math.floor((endPercent / 100) * Count_Total_Events) - 1;

        const Percent = ((startIdx + 1) / Merged_Chrono.length * 100).toFixed(1);
        console.log(`\n🎼 Event ${startIdx + 1}/${Merged_Chrono.length} (${Percent}%)`);    

        for (let i = startIdx; i <= endIdx; i++) { //event can be note or chord
          const Event = Merged_Chrono[i];
          const { notes } = Event;

          const Percent = ((i + 1) / Merged_Chrono.length * 100).toFixed(1);
          console.log(`\n🎼 Event ${i + 1}/${Merged_Chrono.length} (${Percent}%)`);    

          // const mapArray = Object.values(mapNotesLeds); // Convert to array
          console.log(`\nmapNotesLeds:`, mapNotesLeds); 

          // Map MIDI notes to LED indices
          const Targets = notes.map(midiNote => { //indices of lights
            const Led_Entry = mapNotesLeds.find(e => e.midi_note === midiNote);
            if (!Led_Entry) return null; //⛔ No LED mapping for MIDI ${midiNote}
            return Led_Entry.led_index;
          }).filter(e => e !== null); // Remove any that returned null

          // Light up all target LEDs with color
          const ledsToShow = Targets.map(index => [index, Purple_Color]);
          // turnLedOn(ledsToShow);
          await reliableTurnLedOn(ledsToShow);


          // Wait until user presses all the correct keys
          await waitForExactMatch(Event.notes, Merged_Chrono, i, endIdx);

          // Turn off LEDs after correct input
          turnLedOff(Targets);
        }

        console.log(`✅song ends!`);
        playRainbowAnimation(); // 🎉 End celebration
      }

        let activeKeyListener = null; // 🧠 Singleton control for listener instance
        function waitForExactMatch(expectedNotes, chrono, eventIndex, endIndex) {
          return new Promise(resolve => {
            if (activeKeyListener) {
              activeKeyListener.postMessage("stop");
              activeKeyListener.terminate();
              activeKeyListener = null;
            }

            let expectedSet = new Set(expectedNotes);
            const Matched_Held = new Set();
            const Lit_Red_Notes = new Set();
            const Lit_Purple_Notes = new Set();
            const Note_Preview_Map = new Map();

            // const Purple_Color = { r: 222, g: 0, b: 222 };
            const Preview_Colors = [
              null,
              { r: 0, g: 15, b: 0 },
              { r: 10, g: 10, b: 0 },
              { r: 5, g: 0, b: 0 },
            ];

            let currentIndex = eventIndex;
            let lastMatchedNotes = new Set();
            let waitingForRepeatRelease = false;
            let hasStopped = false;

            function setsAreEqual(a, b) {
              return a.size === b.size && [...a].every(n => b.has(n));
            }

            async function lightUpFutureEvents(startIndex) {
              Lit_Purple_Notes.clear();
              Note_Preview_Map.clear();

              const All_Leds_To_Turn_On = [];

              for (let i = 0; i < Preview_Colors.length; i++) {
                const event = chrono[startIndex + i];
                if (!event) continue;

                for (const note of event.notes) {
                  const led = mapNotesLeds.find(e => e.midi_note === note);
                  if (!led) continue;

                  const color = i === 0 ? Purple_Color : Preview_Colors[i]; //purple here???
                  if (!color) continue;

                  const existing = Note_Preview_Map.get(note);
                  if (!existing || i < existing.priority) {
                    Note_Preview_Map.set(note, { color, priority: i });
                    All_Leds_To_Turn_On.push([led.led_index, color]);
                    if (i === 0) Lit_Purple_Notes.add(note);
                  }
                }
              }

              if (All_Leds_To_Turn_On.length) await reliableTurnLedOn(All_Leds_To_Turn_On);
            }

            function turnOffCorrectNotes(notes) {
              const toOff = [...notes].map(n => mapNotesLeds.find(e => e.midi_note === n)?.led_index).filter(Boolean);
              if (toOff.length) turnLedOff(toOff);
            }

            function stopListener(worker) {
              if (hasStopped) return;
              hasStopped = true;
              worker.postMessage("stop");
              worker.terminate();
              activeKeyListener = null;
            }

            lightUpFutureEvents(currentIndex);

            const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
            activeKeyListener = listener;
            listener.postMessage("start");

            listener.onmessage = async function(event) {
              const notes = event.data.map(e => e.note);
              const held = new Set(notes);

              // turn off reds if released
              for (const n of Lit_Red_Notes) {
                if (!held.has(n)) {
                  const led = mapNotesLeds.find(e => e.midi_note === n);
                  if (led) {
                    turnLedOff([led.led_index]);
                    const prev = Note_Preview_Map.get(n);
                    if (prev && !Lit_Purple_Notes.has(n)) {
                      await reliableTurnLedOn([[led.led_index, prev.color]]);
                    }
                  }
                  Lit_Red_Notes.delete(n);
                }
              }

              for (const n of Matched_Held) {
                if (!held.has(n)) Matched_Held.delete(n);
              }

              if (waitingForRepeatRelease) {
                if ([...lastMatchedNotes].some(n => held.has(n))) return;
                waitingForRepeatRelease = false;
              }

              const heldExpected = [...expectedSet].filter(n => held.has(n));
              const isMatch = heldExpected.length === expectedSet.size && heldExpected.every(n => expectedSet.has(n));

              for (const n of held) {
                if (!expectedSet.has(n) && !Matched_Held.has(n) && !Lit_Red_Notes.has(n)) {
                  const led = mapNotesLeds.find(e => e.midi_note === n);
                  if (led) {
                    turnLedOn([[led.led_index, Red_Color]]); //when error, we don't need to turn leds on reliably, just a once and done
                    Lit_Red_Notes.add(n);
                  }
                }
              }

              if (isMatch) {
                turnOffCorrectNotes(expectedSet);
                expectedSet.forEach(n => Matched_Held.add(n));
                lastMatchedNotes = new Set(expectedSet);
                currentIndex++;

                if (currentIndex >= endIndex) {
                  console.log("🏁 End of song reached.\n");
                  stopListener(listener);
                  playRainbowAnimation();
                  resolve();
                  return;
                }

                expectedSet = new Set(chrono[currentIndex].notes);

                const pct = ((currentIndex + 1) / chrono.length * 100).toFixed(1);
                console.log(`\n🎼 Advancing to event ${currentIndex + 1}/${chrono.length} (${pct}%)`);


                if (setsAreEqual(expectedSet, lastMatchedNotes)) {
                  waitingForRepeatRelease = true;
                }

                lightUpFutureEvents(currentIndex);
              }
            };
          });
        }

function learnScalesAndChords() {
  Menu_Row.style.display = 'flex'; //show menu-row IF we selected scales or chords

  const Menu_Note = document.getElementById("menu-note");
  const Menu_Type_Scales = document.getElementById("menu-type-scales");
  const Menu_Type_Chords = document.getElementById("menu-type-chords");
  Menu_Note.value = '';
  Menu_Type_Scales.value = '';
  Menu_Type_Chords.value = '';

  if (selected === 'scales') {
    Menu_Note.value = '';
    Menu_Type_Scales.style.display = 'inline-block';
    Menu_Type_Scales.value = '';
    Menu_Type_Chords.style.display = 'none';

    ["menu-note", "menu-type-scales"].forEach(id => {
      document.getElementById(id).addEventListener("change", (e) => {
        console.log(`🐁${id} changed to ${e.target.value}`);
        updateOctavesMenu(Menu_Note.value, Menu_Type_Scales.value);
      });
    });
  } else if (selected === 'chords') {
    Menu_Note.value = '';
    Menu_Type_Scales.style.display = 'none';
    Menu_Type_Chords.style.display = 'inline-block';
    Menu_Type_Chords.value = '';

    ["menu-note", "menu-type-chords"].forEach(id => {
      document.getElementById(id).addEventListener("change", (e) => {
        console.log(`🐁${id} changed to ${e.target.value}`);
        updateOctavesMenu(Menu_Note.value, Menu_Type_Chords.value);
      });
    });
  }
}

  function updateOctavesMenu(note, type) {
    const Menu_Octave = document.getElementById("menu-octave");
    Menu_Octave.value = '';

    if (note !== "" && type !== "") {
      const Octaves_To_Show = getValidOctaves(note, type);
      console.log(`🐤Octaves_To_Show: ${Octaves_To_Show}`);

      showOctaves(Octaves_To_Show);
    }

    ["menu-octave"].forEach(id => {
      document.getElementById(id).addEventListener("change", (e) => {
        const Octave = Menu_Octave.value;
  
        console.log(`🐱${id} changed to ${e.target.value}`);
        if (note !== "" && type !== "" && Octave !== "") showPattern(note, type, Octave); //only show scale if all options have been chosen; scale and chords use the same algo
      });
    });
  }

    function getValidOctaves(Note, Type) { // partial octaves count too
      console.log(`\n🍌getting valid octaves...`);

      const Base_Semitone = Note_To_Offset[Note]; // example: C → 0

      const Pattern = (selected === 'scales') ? Scale_Patterns[Type] : Chord_Patterns[Type]; // example: [0,2,4,5,7,9,11]
      const Octaves = new Set();                  // will store valid octaves (no duplicates)

      for (const Entry of mapNotesLeds) {
        const midiNote = Entry.midi_note;           // e.g., 21, 22, 23...
        const semitone = midiNote % 12;             // which of the 12 semitones (C=0, C#=1, etc.)
        const octave = Math.floor(midiNote / 12) - 1; // map MIDI note to musical octave number

        // Calculate distance from the root note
        const intervalFromBase = (semitone - Base_Semitone + 12) % 12;
        // Example: if Base_Semitone = 0 (C) and midiNote = 21 (A0 = 9 semitones), interval = 9

        if (Pattern.includes(intervalFromBase)) {
          // If this midiNote fits into the scale/chord pattern relative to root note
          Octaves.add(octave);
          // console.log(`✅ MIDI ${midiNote} (octave ${octave}) fits ${Note} ${Type}`);
        }
      }

      //this sorts ascending (lowest octave first); if we want to sort descending (highest octave first), do b - a instead of a - b
      return Array.from(Octaves).sort((a, b) => a - b);
    }

    function showOctaves(octaves) {
      console.log(`🦒updating octave menu...`);

      const menu = document.getElementById("menu-octave");
    
      // Clear existing options
      menu.innerHTML = "";
    
      //title
      const title = document.createElement("option");
      title.value = "";
      title.textContent = `Octave Range`;
      menu.appendChild(title);
    
      // Add available octaves
      for (const octave of octaves) {
        const option = document.createElement("option");
        option.value = octave;
        option.textContent = `Octave ${octave}`;
        menu.appendChild(option);
      }
    
      // Optionally add a "Select All" or "-1" for all octaves
      const allOption = document.createElement("option");
      allOption.value = -1;
      allOption.textContent = "All";
      menu.appendChild(allOption);
    }

    const IndiceS_Strip_Temp = []; //for turning off later; [index numbers]
    const LedS_Temp = []; //for turning on; [light objects]
    async function showPattern(Note, Type, Octave) { //show the selected scale on led
      console.log("🐹showing scale on led strip...");
    
      console.log(`🍮IndiceS_Strip_Temp: `, IndiceS_Strip_Temp);
      if (IndiceS_Strip_Temp.length > 0) turnOffTempLights(); //reset leds before new scale
    
      if (Octave === -1) console.log(`\n🦮${Note} ${Type}`); //-1 means all instances of this note
      else console.log(`\n🐳${Note}${Octave} ${Type}`);
    
      //algo:
      //✅look at all of Note's instances in map (could be 7-8)
      //✅apply the Type's pattern (an additional 5+ notes)
      //✅all these notes go into LedS_Temp, but don't turn on yet
      //✅IF Octave === -1 (all): then turn on everything so far
      //✅ELSE (any other octave): cap the leds on either side; work on that algo later
      applyNotePattern(Note, Type, Octave);
      // console.log("🐆LedS_Temp:", LedS_Temp);
    
      await reliableTurnLedOn(LedS_Temp);
    }

      function turnOffTempLights() {
        turnLedOff(IndiceS_Strip_Temp);
        IndiceS_Strip_Temp.length = 0;
        LedS_Temp.length = 0;

        console.log(`🐡IndiceS_Strip_Temp: `, IndiceS_Strip_Temp);
        console.log(`🐋LedS_Temp: `, LedS_Temp);
      }

      function applyNotePattern(Note, Type, Octave) {
        const Base_Semitone = Note_To_Offset[Note];        //Note_To_Offset['C'] -> 0

        console.log(`\n🐬selected: ${selected}`); //songs, scales, or chords
        const Pattern = (selected === 'scales') ? Scale_Patterns[Type] : Chord_Patterns[Type]; //Type_Patterns['major] -> [0, 2, 4, 5, 7, 9, 11]
        // console.log(`🐯Base_Semitone: ${Base_Semitone}`);
        console.log(`🐴Pattern: ${Pattern}`);
      
        for (const Entry of mapNotesLeds) {
          const Midi_Note = Entry.midi_note;
          const Semitone = Midi_Note % 12;
          const Note_Octave = Math.floor(Midi_Note / 12) - 1;
          // console.log(`🍭Midi_Note: ${Midi_Note}`);
          // console.log(`💥Semitone: ${Semitone}`);
          // console.log(`🦄Note_Octave: ${Note_Octave}`);
      
          // Calculate interval from base note
          const Interval_From_Base = (Semitone - Base_Semitone + 12) % 12;
          // console.log(`🧀Interval_From_Base: ${Interval_From_Base}`);
      
          // Check if this midiNote fits into the scale/chord pattern
          const Matches_Pattern = Pattern.includes(Interval_From_Base);
          // console.log(`🐑Matches_Pattern: ${Matches_Pattern}`);
      
          // Check octave match (or all octaves if Octave === -1)
          const Matches_Octave = Number(Octave) === -1 || Note_Octave === Number(Octave);
          // console.log(`🙊Matches_Octave: ${Matches_Octave}`);
      
          if (Matches_Pattern && Matches_Octave) {
            // console.log(`🦌matches entry.led_index: ${entry.led_index}`);
      
            LedS_Temp.push([Entry.led_index, getRandomRGB()]);
            IndiceS_Strip_Temp.push(Entry.led_index);
            console.log(`✅ MIDI ${Midi_Note} (octave ${Note_Octave}) → LED ${Entry.led_index}`);
          }
        }
      
        console.log("💡LedS_Temp:", JSON.stringify(LedS_Temp)); //for turning on
        console.log("🌻IndiceS_Strip_Temp:", IndiceS_Strip_Temp); //for turning off
      }