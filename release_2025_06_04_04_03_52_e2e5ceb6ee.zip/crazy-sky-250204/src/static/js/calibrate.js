// console.log("☕🍥calibrate.js");

import { listenForKey } from "./listen.js";
import { keyboardFirstKey, keyboardFirstNote, keyboardFirstOctave, updateKeyboardFirstKey,
  keyboardLastKey, keyboardLastNote, keyboardLastOctave, updateKeyboardLastKey,
  keyboardKeyCount, updateKeyCount, getNoteFromMidi, getOctaveFromMidi,
  cntMaxLeds, avgLedsPerOctave, avgLedsPerSemitone,
  mapNotesLeds, updateMapNotesLeds, updateMapDatabase } from "./global.js";
import { turnLedOn, turnLedOff } from "./led.js";
import { getRandomRGB } from "./color.js"

//gotta be careful of scenario where someone calibrates, then quits midway, the local map may be altered and only be half filled

export function startCalibrating() {
  console.log("\n🧇starting calibrating...");

  getFirstKey();
}

function getFirstKey() {
  // console.log("🥯getting first key...");

  document.getElementById("instructions").innerText = "Play the FIRST key on your keyboard.";

  listenForKey("first");
}

export function setFirstKey(note) {
  // console.log("🍐setting first key...");

  updateKeyboardFirstKey(note); //global

  document.getElementById("first-key").innerText = "first key: " + keyboardFirstNote+keyboardFirstOctave;
  
  getLastKey();
}

function getLastKey() {
  // console.log("🍈getting last key...");

  document.getElementById("instructions").innerText = "Play the LAST key on your keyboard.";

  listenForKey("last");
}

export function setLastKey(note) {
  // console.log("🍯setting last key...");

  updateKeyboardLastKey(note); //global
  updateKeyCount(); //global

  document.getElementById("last-key").innerText = "last key: " + keyboardLastNote+keyboardLastOctave;
  document.getElementById("key-count").innerText = "key count: " + keyboardKeyCount;
  document.getElementById("octaves").innerText = "octaves: " + (keyboardLastOctave-keyboardFirstOctave+1);

  calibrateLeds();
}

let freeLeds = [];
const Midi_Free_WhiteS = [], Midi_Free_BlackS = []; //we do this declaration outside the function calibrateLeds bc we need these values to be locally global
// const DENSITY_LED = 0.160; //160 leds/m, 0.16 led/mm

async function calibrateLeds() {
  console.log("\n🙈calibrating leds...");

  //we do this assignment inside the function bc we know it'll get called after global.js has had its chance to define the max number (by reading the database)
  freeLeds = Array.from({ length: cntMaxLeds }, (_, i) => i); //gives [0, 1, 2, 3, ..., 199 - where 199 is the hard cap we gave in the database]

  getBlackAndWhiteKeys(); //look at the current whites and blacks and see what we have

  document.querySelector(".row.with-arrows").style.display = "flex";

  midiFirst = keyboardFirstKey; //comes from white array, but used for both white and black functions; will be NaN here, so we have to define it in-function too; defining here merely for clarity
  console.log(`🌕midiFirst: ${midiFirst}`);
  await loopWhiteKeys(); //if no await, the loops will run together
  await loopBlackKeys();

  save();
}

function getBlackAndWhiteKeys() {
    const whiteNotes = [0, 2, 4, 5, 7, 9, 11]; // C, D, E, F, G, A, B
    
    for (let midi = keyboardFirstKey; midi <= keyboardLastKey; midi++) {
      const noteInOctave = midi % 12;
      
      whiteNotes.includes(noteInOctave) ? Midi_Free_WhiteS.push(midi) : Midi_Free_BlackS.push(midi);
    }
  
    // console.log("🍤Midi_Free_WhiteS: " + Midi_Free_WhiteS);
    // console.log("🥩Midi_Free_BlackS: " + Midi_Free_BlackS);
}

const Leds_Temp = []; //the leds we'll be dealing with for 1 loop (ex: for all the A notes); light objects
const IndiceS_Temp = []; //the indices we'll be dealing with for 1 loop (ex: for all the A notes); led indices for the strip

let MAP_NOTES_LEDS = {
  //to add/update(aka upsert) key: MAP_NOTES_LEDS[21]=3;
  //to delete key: delete MAP_NOTES_LEDS[21]
  //to read/check key: MAP_NOTES_LEDS[21]
};

let midiFirst; //comes from white array, but used for both white and black functions; will be NaN here, so we have to define it in-function too; defining here merely for clarity

//sample Midi_Free_WhiteS = [21,23,24,26,28,29,31,33,35,36,38,40,41,43,45,47,48,50,52,53,55,57,59,60,62,64,65,67,69,71,72,74,76,77,79,81,83,84,86,88,89,91,93,95,96,98,100,101,103,105,107,108];
const Index_Strip_First_White = 2; //start at [2] bc 0 and 1 is too far left and won't match with any keyboard key; experimentally derived

//we eventually want to hit every key in this array (52), but the outer loop will only go through the 7 white notes (A to G)
//for each note (A through G), we go through 7-8 iterations (1 for each octave) -- this is the inner loop
async function loopWhiteKeys() { //calibrate white keys first; loop until all whites are calibrated
  console.log(`\n🐲starting loop for white keys; midi for all white keys (${Midi_Free_WhiteS.length}): ${Midi_Free_WhiteS}`); //52 white keys
  const Midi_Last_White = Midi_Free_WhiteS[Midi_Free_WhiteS.length-1]; //so we know how far to loop for
  console.log(`Midi_Last_White: ${Midi_Last_White}`);

  // --- OUTER LOOP --- increments over the white keys (7 in total)
  while (Midi_Free_WhiteS.length > 0) { //if Midi_Free_WhiteS not yet empty, we continue to process; each loop we go through is a note (A,B,...,F,G)
    //MIDI part
    const Midi_Temp_WhiteS = []; //the white keys we'll be dealing with this loop (ex: all the A notes)
    const Midi_First_White = Midi_Free_WhiteS[0]; //first of the notes, ex: B1 (24); will always be [0] bc array will be updated every loop
    console.log(`\nMidi_First_White: ${Midi_First_White} (${getNoteFromMidi(Midi_First_White)})`);

    //LED part
    const LedS_To_Check = [];

    //still gotta up the leds by a few every time we switch note up
    const Dist_Semitones = Midi_First_White - midiFirst;                //how many semitones from start midi note to current iteration              //ex: F1 minus A0                               //29 midi - 21 midi = 8 semitones
    const Dist_Leds = Dist_Semitones * avgLedsPerSemitone;              //count of ~how many leds from A0 to F1 (defined as led[2], the 3rd led)    //semitones * leds/semitone = leds, rounded     //8 semitones * 2.1... leds/semitone = 17.5... leds -> 18 leds
    const Dist_Rounded = Math.round(Dist_Leds);                         
    const Index_Strip_Start = Dist_Rounded + Index_Strip_First_White;   //index of led for this iteration's note                                    //leds difference + led start = led new         //18 leds + strip[2] = strip[20], the 21st led in strip
    // console.log(`🌓🎶Dist_Semitones: ${Dist_Semitones} - 🚨Dist_Leds: ${Dist_Leds} - ↕️Dist_Rounded: ${Dist_Rounded} - 🚥Index_Strip_Start: ${Index_Strip_Start}\n`);
    //strip[2] and freeLeds[2] were the same at the start, but strip[20] is no longer freeLeds[20] after several iterations; find x, where freeLeds[x] is closest to strip[20]

    // --- INNER LOOP --- increments over the octaves (7-8 in total) for each note
    for (let semitone = Midi_First_White; semitone <= Midi_Last_White; semitone += 12) { //+12 semitones is one full octave up
      //MIDI part
      if (Midi_Free_WhiteS.includes(semitone)) Midi_Temp_WhiteS.push(semitone);

      //LED part
      const Dist_Semitones = semitone - Midi_First_White;
      const Dist_Leds = Dist_Semitones * avgLedsPerSemitone; //is decimal
      const Dist_Rounded = Math.round(Dist_Leds); //distance in leds from A0 [2]
      const Index_Strip = Dist_Rounded + Index_Strip_Start; //[2] would be 3rd led in the strip
      // console.log(`🎶Dist_Semitones: ${Dist_Semitones} - 🚨Dist_Leds: ${Dist_Leds} - ↕️Dist_Rounded: ${Dist_Rounded} - 🚥Index_Strip: ${Index_Strip}`);

      LedS_To_Check.push([Index_Strip, getRandomRGB()]);

      IndiceS_Temp.push(Index_Strip); //for user to see if correct; can correct with arrows
    }
    console.log(`Midi_Temp_WhiteS: ${Midi_Temp_WhiteS}`); //ex: all A notes

    turnLedOn(LedS_To_Check);
    showBoxes(); //showboxes should use freeLeds, so we can move left right freely

    await confirm(Midi_Temp_WhiteS, IndiceS_Temp); //place these leds into used array and remove from freeLeds //confirm is user click, loop won't iterate until user input

    console.log("\n🐽MAP_NOTES_LEDS (midi_note:led_index): " + JSON.stringify(MAP_NOTES_LEDS));

    // console.log("\n🐗clearing leds...");
    turnLedOff(IndiceS_Temp); //turn off only the ones that were on (much faster); clearing entire strip takes too long and will overlap with led on events

    //remove temps from frees
    console.log("🐖removing temps from frees...");
    removeCommonArrayElements(freeLeds, IndiceS_Temp);
    console.log(`🐓freeLeds cropped (${freeLeds.length}): ${freeLeds}`);

    //clear selecteds
    // console.log("🐃clearing selecteds...");
    const SELECTED_BOXES = document.querySelectorAll(".light-box.selected");
    SELECTED_BOXES.forEach((box, i) => {
      box.classList.remove("selected");
    });

    removeCommonArrayElements(Midi_Free_WhiteS, Midi_Temp_WhiteS); //ex: remove all A notes after done
  }  
}

//sample Midi_Free_BlackS = [22,25,27,30,32,34,37,39,42,44,46,49,51,54,56,58,61,63,66,68,70,73,75,78,80,82,85,87,90,92,94,97,99,102,104,106];
const Index_Strip_First_Black = 5; //start at [5] bc 0-4 is too far left and won't match with any keyboard key; experimentally derived

//we eventually want to hit every key in this array (36), but the outer loop will only go through the 5 black notes (A# to G#)
//for each note (A# through G#), we go through 7-8 iterations (1 for each octave) -- this is the inner loop
async function loopBlackKeys() { //calibrate black keys second; loop until all blacks are calibrated
  console.log(`\n🐧starting loop for black keys; midi for all black keys (${Midi_Free_BlackS.length}): ${Midi_Free_BlackS}`); //36 black keys
  const Midi_Last_Black = Midi_Free_BlackS[Midi_Free_BlackS.length-1]; //so we know how far to loop for
  console.log(`Midi_Last_Black: ${Midi_Last_Black}`);  
  
  // --- OUTER LOOP --- increments over the black keys (5 in total)
  while (Midi_Free_BlackS.length > 0) { //if Midi_Free_BlackS not yet empty, we continue to process; each loop we go through is a note (A#,C#,...,E#,F#)
    //MIDI part
    const Midi_Temp_BlackS = []; //the black keys we'll be dealing with this loop (ex: all the A# notes)
    const Midi_First_Black = Midi_Free_BlackS[0]; //first of the notes, ex: B#1 (25); will always be [0] bc array will be updated every loop
    console.log(`\nMidi_First_Black: ${Midi_First_Black} (${getNoteFromMidi(Midi_First_Black)})`);

    //LED part
    const LedS_To_Check = [];

    //still gotta up the leds by a few every time we switch note up
    const Dist_Semitones = Midi_First_Black - 22; //22 just works best  //how many semitones from start midi note to current iteration              //ex: F#1 minus A#0                             //30 midi - 22 midi = 8 semitones
    const Dist_Leds = Dist_Semitones * avgLedsPerSemitone;              //count of ~how many leds from A#0 to F#1 (defined as led[5], the 6th led)  //semitones * leds/semitone = leds, rounded     //8 semitones * 2.1... leds/semitone = 17.5... leds -> 18 leds
    const Dist_Rounded = Math.round(Dist_Leds);                         
    const Index_Strip_Start = Dist_Rounded + Index_Strip_First_Black;   //index of led for this iteration's note                                    //leds difference + led start = led new         //18 leds + strip[5] = strip[23], the 24th led in strip
    // console.log(`🌐🎶Dist_Semitones: ${Dist_Semitones} - 🚨Dist_Leds: ${Dist_Leds} - ↕️Dist_Rounded: ${Dist_Rounded} - 🚥Index_Strip_Start: ${Index_Strip_Start}\n`);
    //strip[5] and freeLeds[5] were the same at the start, but strip[20] is no longer freeLeds[20] after several iterations; find x, where freeLeds[x] is closest to strip[20]

    // --- INNER LOOP --- increments over the octaves (7-8 in total) for each note
    for (let semitone = Midi_First_Black; semitone <= Midi_Last_Black; semitone += 12) { //+12 semitones is one full octave up
      //MIDI part
      if (Midi_Free_BlackS.includes(semitone)) Midi_Temp_BlackS.push(semitone);

      //LED part
      const Dist_Semitones = semitone - Midi_First_Black;
      const Dist_Leds = Dist_Semitones * avgLedsPerSemitone; //is decimal
      const Dist_Rounded = Math.round(Dist_Leds); //distance in leds from A#0 [5]
      const Index_Strip = Dist_Rounded + Index_Strip_Start; //[5] would be 6th led in the strip
      // console.log(`🎶Dist_Semitones: ${Dist_Semitones} - 🚨Dist_Leds: ${Dist_Leds} - ↕️Dist_Rounded: ${Dist_Rounded} - 🚥Index_Strip: ${Index_Strip}`);

      LedS_To_Check.push([Index_Strip, getRandomRGB()]);

      IndiceS_Temp.push(Index_Strip); //for user to see if correct; can correct with arrows
    }
    console.log(`Midi_Temp_BlackS: ${Midi_Temp_BlackS}`); //ex: all A# notes

    turnLedOn(LedS_To_Check);
    showBoxes(); //showboxes should use freeleds, so we can move left right freely
    
    await confirm(Midi_Temp_BlackS, IndiceS_Temp); //place these leds into used array and remove from freeLeds //confirm is user click, loop won't iterate until user input

    console.log("🦓MAP_NOTES_LEDS (midi_note:led_index): " + JSON.stringify(MAP_NOTES_LEDS));

    // console.log("🐏clearing leds...");
    turnLedOff(IndiceS_Temp); //turn off only the ones that were on (much faster); clearing entire strip takes too long and will overlap with led on events

    //remove temps from frees
    console.log("🐂removing temps from frees...");
    removeCommonArrayElements(freeLeds, IndiceS_Temp);
    console.log(`🌼freeLeds cropped (${freeLeds.length}): ${freeLeds}`);

    //clear selecteds
    // console.log("🐪clearing selecteds...");
    const SELECTED_BOXES = document.querySelectorAll(".light-box.selected");
    SELECTED_BOXES.forEach((box, i) => {
      box.classList.remove("selected");
    });

    removeCommonArrayElements(Midi_Free_BlackS, Midi_Temp_BlackS); //ex: remove all A# notes after done
  }
}

function removeCommonArrayElements(arr1, arr2) {
  // console.log(`arr1 & arr2 lengths: ${arr1.length} & ${arr2.length}`);

  arr1.slice().forEach(value => {
    if (arr2.includes(value)) {
      
      let index;

      while ((index = arr1.indexOf(value)) !== -1) {
        arr1.splice(index, 1); // Remove from arr1
      }

      while ((index = arr2.indexOf(value)) !== -1) {
        arr2.splice(index, 1); // Remove from arr2
      }
    }
  });

  // console.log(`arr1 & arr2 lengths: ${arr1.length} & ${arr2.length}`);
}

function showBoxes() {
  // console.log("🐮showing boxes...");

  const COUNT = IndiceS_Temp.length;
  const BOXES = document.querySelectorAll(".light-box"); //we premade 10 of these babies in html, hopefully no keyboard needs more than that; 88key keyboard would need a max of 8
  
  setArrowButtons();

  BOXES.forEach((box, i) => {
    box.style.display = "none";
    if (i < COUNT) {
      box.style.display = "flex";
      box.innerText = IndiceS_Temp[i];

      box.onclick = () => toggleSelect(box); //make it look obvious //once selected, the square(s) can be moved left and right; lights will follow
    }  
  });
}

async function setArrowButtons() {
  // console.log("🦬setting arrow buttons...");

  //for any given led index, we have to know what index number is directly adjacent to it? must look in free leds
  //when arrow clicks, we have to check which boxes are selected; check its corresponding index for leds
 
  document.getElementById('arrow-left').onclick = () => {
    console.log("\n🍀🌾clicked LEFT <-- <-- <-- !!!");

    // console.log(`🐸freeLeds (${freeLeds.length}) unaltered: ${freeLeds}`);

    const SELECTED_BOXES = document.querySelectorAll(".light-box.selected"); //must query latest selections every time we click

    for (const SELECTED_BOX of SELECTED_BOXES) { //using for, we naturally move from left-most to right; REMEMBER to reverse i going the other way
      const Number_On_box = parseInt(SELECTED_BOX.innerText); //number is led index that's written on this box
      const INDEX_IN_FREELEDS = freeLeds.indexOf(Number_On_box); //find this index number in freeLeds
      const LEFT = INDEX_IN_FREELEDS - 1; //led index of its left neighbor
      console.log("\n🦢Number_On_box (led index to move left): " + Number_On_box);
      console.log("🦉INDEX_IN_FREELEDS (location of Number_On_box inside freeLeds[]): " + INDEX_IN_FREELEDS);
      console.log("🦤LEFT (the leftward number inside freeLeds[]): " + LEFT);
      console.log("🦆IndiceS_Temp (0 change): " + IndiceS_Temp);
      
      /* 3 questions we must ask:
        - is Number_On_box = 0?                         - we lack the physical available led to move left
        - is INDEX_IN_FREELEDS = 0?                     - if so, we have used up all available lights to the left of this
        - is LEFT = a number already in IndiceS_Temp?   - a light cannot move past its neighbor
        if we CANNOT move left, Number_On_box does not change, IndiceS_Temp does not change; if we CAN move left, both change */
      if (Number_On_box === 0) {
        console.log("🪲CASE1");
        return;
      }
      if (INDEX_IN_FREELEDS === 0) {
        console.log("🌲CASE2");
        return;
      }
      if (IndiceS_Temp.includes(freeLeds[LEFT])) {
        console.log("🕷CASE3");
        return;
      }
  
      //change Number_On_box
      SELECTED_BOX.innerText = freeLeds[LEFT];

      //change IndiceS_Temp
      const INDEX = IndiceS_Temp.indexOf(Number_On_box);
      IndiceS_Temp[INDEX] = freeLeds[LEFT];
      console.log("🌎IndiceS_Temp (updated): " + IndiceS_Temp);

      //change led
      turnLedOff([freeLeds[INDEX_IN_FREELEDS]]);
      turnLedOn([[freeLeds[LEFT], getRandomRGB()]]);
    }
  };

  document.getElementById('arrow-right').onclick = () => {
    console.log("\n🍁🌿clicked RIGHT --> --> --> !!!");

    // console.log(`🐊freeLeds (${freeLeds.length} unaltered): ${freeLeds}`);

    const SELECTED_BOXES = document.querySelectorAll(".light-box.selected"); //must query latest selections every time we click

    for (const SELECTED_BOX of [...SELECTED_BOXES].reverse()) { //reverse so we now check from right-most numbers first
      const Number_On_box = parseInt(SELECTED_BOX.innerText); //number is led index that's written on this box
      const INDEX_IN_FREELEDS = freeLeds.indexOf(Number_On_box); //find this index number in freeLeds
      const RIGHT = INDEX_IN_FREELEDS + 1; //led index of its right neighbor
      console.log("\n🪶Number_On_box (led index to move right): " + Number_On_box); //33
      console.log("🦩INDEX_IN_FREELEDS (location of Number_On_box inside freeLeds[]): " + INDEX_IN_FREELEDS); //31
      console.log("🐢RIGHT (the rightward number inside freeLeds[]): " + RIGHT); //32
      console.log("🦎IndiceS_Temp (0 change): " + IndiceS_Temp);

      /* 3 questions we must ask:
        - is Number_On_box = max?                         - we lack the physical available led to move right (1-off error may creep in here, but it shouldnt really be a huge deal since we don't really know how many leds there are exactly anyway)
        - is INDEX_IN_FREELEDS = the last index?          - if so, we have used up all available lights to the right of this
        - is RIGHT = a number already in IndiceS_Temp?    - a light cannot move past its neighbor
        if we CANNOT move right, Number_On_box does not change, IndiceS_Temp does not change; if we CAN move right, both change */
      if (Number_On_box === cntMaxLeds-1) {
        console.log("🐞CASE1");
        return;
      }
      if (INDEX_IN_FREELEDS === INDEX_IN_FREELEDS[freeLeds.length-1]) {
        console.log("🪳CASE2");
        return;
      }
      if (IndiceS_Temp.includes(freeLeds[RIGHT])) {
        console.log("🦗CASE3");
        return;
      }
  
      //change Number_On_box
      SELECTED_BOX.innerText = freeLeds[RIGHT];

      //change IndiceS_Temp
      const INDEX = IndiceS_Temp.indexOf(Number_On_box);
      IndiceS_Temp[INDEX] = freeLeds[RIGHT];
      console.log("🦑IndiceS_Temp (updated): " + IndiceS_Temp);

      //change led
      turnLedOff([freeLeds[INDEX_IN_FREELEDS]]);
      turnLedOn([[freeLeds[RIGHT], getRandomRGB()]]);
    }
  };
}

function confirm(KeyS, ValueS) { //ValueS is the TEMP_INDICES from the parent function
  return new Promise((resolve) => {
    const BUTTON = document.getElementById("confirm-button");
    
    const HANDLE_CLICK = () => {
      console.log("\n🌍🍂CONFIRMED!!!");
      
      BUTTON.removeEventListener("click", HANDLE_CLICK); //remove handler after it's been triggered (to prevent multiple triggers)

      KeyS.forEach((key, i) => { //mapping keys and values
        MAP_NOTES_LEDS[key] = ValueS[i]; //midi = led index

        //full map will be uploaded to database in save()
      });
  
      //calculate average distance between leds
      // const DIFF_INDICES = Math.max(...ValueS) - Math.min(...ValueS); //largest led index minus smallest led index
      // const COUNT_SPACE = ValueS.length-1; //ex: [1,3,5,7,9] there are 4 spaces between numbers
      // const AVG_LEDS_PER_SPACE = DIFF_INDICES/COUNT_SPACE; //leds/space
      // console.log("\n🦇BIG_DIFF: " + DIFF_INDICES);
      // console.log("🐻‍❄️COUNT_SPACE: " + COUNT_SPACE);
      // console.log("🐻AVG_LEDS_PER_SPACE: " + AVG_LEDS_PER_SPACE);

      //calculate average distance between keys
      // const DIFF_KEYS = Math.max(...KeyS) - Math.min(...KeyS); //largest midi minus smallest midi
      // const COUNT_SEMITONES = DIFF_KEYS+1; //ex: from 48 to 60, there are 13 semitones, inclusively
      // const AVG_LED_PER_SEMITONES = DIFF_INDICES/COUNT_SEMITONES; //leds/semitone
      // console.log("\n🐼DIFF_KEYS: " + DIFF_KEYS);
      // console.log("🦥COUNT_SEMITONES: " + COUNT_SEMITONES);
      // console.log("🐨AVG_LED_PER_SEMITONES: " + AVG_LED_PER_SEMITONES);
      
      resolve(); //special function; resolves the promise, allowing parent loop to continue
    };

    BUTTON.addEventListener("click", HANDLE_CLICK);
  });
}

function toggleSelect(element) {
  if (element.classList.contains("selected")) element.classList.remove("selected");
  else element.classList.add("selected");
}

function save() { //save into global variable; update database
  console.log("\n🐰saving...");

  updateMapDatabase(MAP_NOTES_LEDS); //do this first, it takes longer, it's async
  updateMapNotesLeds(MAP_NOTES_LEDS);

  console.log("🐀mapNotesLeds: " + mapNotesLeds);


  
//if update fully successful; how to check?



  fetch("/api/set_config/keys_calibrated", { //turn keys_calibrated from FALSE into TRUE; basically toggling switch from off to on (regarding calibration completion); if already calibrated, will just overwrite with TRUE again
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "value=" + encodeURIComponent(JSON.stringify(true))
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      console.log("🐛keys calibrated!");
      document.getElementById('txt-calibration-reminder').innerText = "we done here"
    } else {
      console.error("⚠️ Error updating lights.");
    }
  })
  .catch(error => {
    console.error("❌ Request failed:", error);
  });

  gsap.to( window, { scrollTo:"#cont-0", duration:1, ease:"power2.out" }); //move to correct container
}