console.log("🦖🦛🍗play.js");

import { mapNotesLeds, keyboardFirstKey, keyboardLastKey, cntMaxLeds } from "./global.js";
import { getRandomRGB } from "./color.js";
import { turnLedOn, turnLedOff } from "./led.js";

const Play_Styles = document.getElementById("play-styles"); //choices: songs/scales/chords

export function startPlaying() {
    console.log("\n🌺starting playing...");

    Play_Styles.value = '';
    Play_Styles.addEventListener("change", () => {
      const Style = Play_Styles.value; //choices: different way lights will react to playing
      console.log(`\n🦜Style: ${Style}`);
  
      if (Style === 'songs') learnSongs();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'songs') learnScalesAndChords();
      else if (Style === 'memory') memory();
      else if (Style === 'spark') spark();
      else if (Style === 'rainbow') listenRedToIndigoWithFade();
      else if (Style === 'wave') wave();
      else if (Style === 'random') listenLivePlayWithFade();
      else if (Style === 'vel_brght') listenLiveVelocityWithFade();
      else if (Style === 'vel_rnbw') listenLiveRainbowVelocity();
      else if (Style === 'ripple') ripple();
    });

    //start listening and just show lights, easy peasy
    // listenLivePlay();
} 

function listenLivePlay() {
    // Stop any previous listener
    if (window.activeLiveListener) {
      window.activeLiveListener.postMessage("stop");
      window.activeLiveListener.terminate();
      window.activeLiveListener = null;
    }
  
    const noteToLedMap = new Map(); // Track which LED is lit for each note
  
    const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
    window.activeLiveListener = listener;
    listener.postMessage("start");
  
    listener.onmessage = function(event) {
      const currentNotes = event.data.map(e => e.note);
      const currentlyHeld = new Set(currentNotes);
  
      // 1. Turn ON for newly pressed notes
      for (const note of currentlyHeld) {
        if (!noteToLedMap.has(note)) {
          const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
          if (ledEntry) {
            const color = getRandomRGB();
            noteToLedMap.set(note, { led: ledEntry.led_index, color });
            turnLedOn([[ledEntry.led_index, color]]);
          }
        }
      }
  
      // 2. Turn OFF for released notes
      for (const [note, { led }] of noteToLedMap.entries()) {
        if (!currentlyHeld.has(note)) {
          turnLedOff([led]);
          noteToLedMap.delete(note);
        }
      }
    };
  
    console.log("🎹 Live play mode: active!");
}

function listenLivePlayWithFade() {
    // Stop any previous listener
    if (window.activeLiveListener) {
      window.activeLiveListener.postMessage("stop");
      window.activeLiveListener.terminate();
      window.activeLiveListener = null;
    }
  
    const noteToLedMap = new Map(); // note → { led, color }
  
    const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
    window.activeLiveListener = listener;
    listener.postMessage("start");
  
    listener.onmessage = function(event) {
      const currentNotes = event.data.map(e => e.note);
      const currentlyHeld = new Set(currentNotes);
  
      // 1. Turn ON for newly pressed notes
      for (const note of currentlyHeld) {
        if (!noteToLedMap.has(note)) {
          const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
          if (ledEntry) {
            const color = getRandomRGB();
            noteToLedMap.set(note, { led: ledEntry.led_index, color });
            turnLedOn([[ledEntry.led_index, color]]);
          }
        }
      }
  
      // 2. Fade out released notes
      for (const [note, { led, color }] of noteToLedMap.entries()) {
        if (!currentlyHeld.has(note)) {
          noteToLedMap.delete(note);
          fadeLedToBlack(led, color);
        }
      }
    };
  
    console.log("🌈 Live play mode with fade enabled!");
}

function fadeLedToBlack(ledIndex, {r,g,b}, steps=30, interval=10) {
  let currentStep = 0;

  const stepFade = () => {
    const t = 1 - currentStep / steps;
    const faded = {
      r: Math.round(r * t),
      g: Math.round(g * t),
      b: Math.round(b * t)
    };

    turnLedOn([[ledIndex, faded]]);
    currentStep++;

    if (currentStep <= steps) {
      setTimeout(stepFade, interval);
    } else {
      turnLedOff([ledIndex]);
    }
  };

  stepFade();
}
  
function listenLiveVelocityWithFade() {
  // Stop previous listener if active
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // MIDI → { led, color }

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const notesHeld = event.data;

    const currentlyHeld = new Set(notesHeld.map(e => e.note));

    // Light up new notes
    for (const { note, velocity } of notesHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const brightness = velocity / 127; // normalize 0–1
          const baseColor = getRandomRGB();
          const scaledColor = {
            r: Math.round(baseColor.r * brightness),
            g: Math.round(baseColor.g * brightness),
            b: Math.round(baseColor.b * brightness)
          };

          noteToLedMap.set(note, { led: ledEntry.led_index, color: scaledColor });
          turnLedOn([[ledEntry.led_index, scaledColor]]);
        }
      }
    }

    // Fade out released notes
    for (const [note, { led, color }] of noteToLedMap.entries()) {
      if (!currentlyHeld.has(note)) {
        noteToLedMap.delete(note);
        fadeLedToBlack(led, color);
      }
    }
  };

  console.log("🎹 Live velocity play mode enabled!");
}

function listenLiveRainbowVelocity() {
  // Stop previous listener if active
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // MIDI → { led, color }

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const notesHeld = event.data;
    const currentlyHeld = new Set(notesHeld.map(e => e.note));

    for (const { note, velocity } of notesHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const hue = Math.floor((velocity / 127) * 270); // red (0) → indigo (270)
          const color = hslToRgb(hue, 1, 0.5); // full saturation, mid-lightness

          noteToLedMap.set(note, { led: ledEntry.led_index, color });
          turnLedOn([[ledEntry.led_index, color]]);
        }
      }
    }

    for (const [note, { led, color }] of noteToLedMap.entries()) {
      if (!currentlyHeld.has(note)) {
        noteToLedMap.delete(note);
        fadeLedToBlack(led, color);
      }
    }
  };

  console.log("🌈 Rainbow velocity mode enabled!");
}

function hslToRgb(h, s, l) {
  h = h % 360;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs((h / 60) % 2 - 1));
  const m = l - c / 2;

  let r = 0, g = 0, b = 0;
  if (h < 60)       [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else              [r, g, b] = [c, 0, x];

  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((b + m) * 255)
  };
}

function listenRedToIndigoWithFade() {
  // Stop any previous listener
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // note → { led, color }

  const midiStart = keyboardFirstKey; // must be globally defined
  const midiEnd = keyboardLastKey;    // must be globally defined

  function midiToHueColor(midiNote) {
    // Hue: 0 (red) to 275 (indigo)
    const hue = ((midiNote - midiStart) / (midiEnd - midiStart)) * 275;
    return hsvToRgb(hue);
  }

  function hsvToRgb(h, s = 1, v = 1) {
    let f = (n, k = (n + h / 60) % 6) =>
      v - v * s * Math.max(Math.min(k, 4 - k, 1), 0);
    return {
      r: Math.round(f(5) * 255),
      g: Math.round(f(3) * 255),
      b: Math.round(f(1) * 255),
    };
  }

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const currentNotes = event.data.map(e => e.note);
    const currentlyHeld = new Set(currentNotes);

    // 1. Turn ON for newly pressed notes
    for (const note of currentlyHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const color = midiToHueColor(note);
          noteToLedMap.set(note, { led: ledEntry.led_index, color });
          turnLedOn([[ledEntry.led_index, color]]);
        }
      }
    }

    // 2. Fade out released notes
    for (const [note, { led, color }] of noteToLedMap.entries()) {
      if (!currentlyHeld.has(note)) {
        noteToLedMap.delete(note);
        fadeLedToBlack(led, color);
      }
    }
  };

  console.log("🌈 Live play with MIDI→Color mapping (red→indigo) is active!");
}

const baseColor = { r: 100, g: 100, b: 255 };
// When a key is pressed, a ripple effect radiates outwards from the corresponding LED:
//     Nearby LEDs glow with diminishing brightness.
//     Color can be based on the key's pitch.
// 💡 Great for dramatic or emotional play.
// is not dealing well with chords and consecutive keys played
function rippleEffect(ledIndex, baseColor, radius = 5, delay = 40) {
  const leds = [];

  for (let offset = -radius; offset <= radius; offset++) {
    const i = ledIndex + offset;
    if (i < 0 || i >= cntMaxLeds) continue;

    // Calculate intensity: strongest at center, fading outwards
    const distance = Math.abs(offset);
    const factor = 1 - distance / (radius + 1); // normalize: 1.0 at center → 0 at edge

    const fadedColor = {
      r: Math.round(baseColor.r * factor),
      g: Math.round(baseColor.g * factor),
      b: Math.round(baseColor.b * factor)
    };

    setTimeout(() => {
      turnLedOn([[i, fadedColor]]);
    }, delay * distance); // each ring delayed outward
  }

  // Optional: fade out the whole ripple after a while
  setTimeout(() => {
    const toOff = [];
    for (let offset = -radius; offset <= radius; offset++) {
      const i = ledIndex + offset;
      if (i >= 0 && i < cntMaxLeds) {
        toOff.push(i);
      }
    }
    turnLedOff(toOff);
  }, delay * (radius + 2) + 100);
}

function ripple() {
  // Stop any previous listener
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // Track which LED is lit for each note

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const currentNotes = event.data.map(e => e.note);
    const currentlyHeld = new Set(currentNotes);

    // 1. Turn ON for newly pressed notes
    for (const note of currentlyHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const color = getRandomRGB();
          noteToLedMap.set(note, { led: ledEntry.led_index, color });
          // turnLedOn([[ledEntry.led_index, color]]);
          rippleEffect(ledEntry.led_index, color);
        }
      }
    }

    // 2. Turn OFF for released notes
    // for (const [note, { led }] of noteToLedMap.entries()) {
    //   if (!currentlyHeld.has(note)) {
    //     turnLedOff([led]);
    //     noteToLedMap.delete(note);
    //   }
    // }
  };

  console.log("🎹 Live play mode: active!");
}



function wave() {
  // Stop any previous listener
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // Track which LED is lit for each note

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const currentNotes = event.data.map(e => e.note);
    const currentlyHeld = new Set(currentNotes);

    // 1. Turn ON for newly pressed notes
    for (const note of currentlyHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const color = getRandomRGB();
          noteToLedMap.set(note, { led: ledEntry.led_index, color });
          // turnLedOn([[ledEntry.led_index, color]]);
          waveSweep(color);
        }
      }
    }
  };

  console.log("🎹 Live play mode: active!");
}

// 🌊 2. Wave Sweep
// A slow, continuous wave of color moves across the keyboard:
//     Notes played momentarily "interrupt" the wave with their own color.
//     Could reflect tempo or pulse of a backing beat.
//some lights aren't turning off
//only reflects 2 notes played
function waveSweep(color = { r:0,g:150,b:255 }, speed=30, length=10) {
  for (let i = 0; i < cntMaxLeds + length; i++) {
    setTimeout(() => {
      const ledsToTurnOn = [];

      for (let j = 0; j < length; j++) {
        const index = i - j;
        if (index >= 0 && index < cntMaxLeds) {
          // Fade based on how far this LED is from the wave center
          const fadeFactor = 1 - j / length;
          const fadedColor = {
            r: Math.round(color.r * fadeFactor),
            g: Math.round(color.g * fadeFactor),
            b: Math.round(color.b * fadeFactor),
          };
          ledsToTurnOn.push([index, fadedColor]);
        }
      }

      // Turn on the current wave segment
      turnLedOn(ledsToTurnOn);

      // Turn off previous LED after wave passes
      const turnOffIndex = i - length;
      if (turnOffIndex >= 0 && turnOffIndex < cntMaxLeds) {
        turnLedOff([turnOffIndex]);
      }

    }, i * speed);
  }

  // Final cleanup: turn everything off after full sweep
  setTimeout(() => {
    const all = Array.from({ length: cntMaxLeds }, (_, i) => i);
    turnLedOff(all);
  }, (cntMaxLeds + length) * speed + 500);
}




function spark() {
  // Stop previous listener if active
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // MIDI → { led, color }

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const notesHeld = event.data;

    const currentlyHeld = new Set(notesHeld.map(e => e.note));

    // Light up new notes
    for (const { note, velocity } of notesHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const brightness = velocity / 127; // normalize 0–1
          const baseColor = getRandomRGB();
          const scaledColor = {
            r: Math.round(baseColor.r * brightness),
            g: Math.round(baseColor.g * brightness),
            b: Math.round(baseColor.b * brightness)
          };

          noteToLedMap.set(note, { led: ledEntry.led_index, color: scaledColor });
          // turnLedOn([[ledEntry.led_index, scaledColor]]);
          velocitySparks(note, velocity)
        }
      }
    }

    // Fade out released notes
    for (const [note, { led, color }] of noteToLedMap.entries()) {
      if (!currentlyHeld.has(note)) {
        noteToLedMap.delete(note);
        fadeLedToBlack(led, color);
      }
    }
  };

  console.log("🎹 Live velocity play mode enabled!");
}

// 🔊 3. Velocity Sparks
// Each note hit causes a spark-like scatter of light:
//     Velocity determines how many nearby LEDs "spark" out from the point.
//     Good for jazz, percussion, or expressive playing.
// doesn't seem to do anything
function velocitySparks(note, velocity) {
  const entry = mapNotesLeds.find(e => e.midi_note === note);
  if (!entry) return;

  const center = entry.led_index;
  const totalLEDs = getTotalLedCount();

  // Scale how far the sparks should spread (max 10 LEDs)
  const maxSpread = Math.floor((velocity / 127) * 10);
  const baseColor = velocityToColor(velocity);

  for (let offset = 0; offset <= maxSpread; offset++) {
    const fade = 1 - offset / (maxSpread + 1);
    const fadedColor = {
      r: Math.round(baseColor.r * fade),
      g: Math.round(baseColor.g * fade),
      b: Math.round(baseColor.b * fade),
    };

    const indices = [];
    if (center + offset < totalLEDs) indices.push(center + offset);
    if (center - offset >= 0) indices.push(center - offset);

    // Schedule the spark lighting
    setTimeout(() => {
      const sparkArray = indices.map(index => [index, fadedColor]);
      turnLedOn(sparkArray);
    }, offset * 20); // Spark speed

    // Schedule fade-out
    setTimeout(() => {
      turnLedOff(indices);
    }, (offset * 20) + 200);
  }
}


function velocityToColor(velocity) {
  const t = velocity / 127; // Normalize 0 to 1
  return {
    r: Math.round(255 * (1 - t)),     // redder at low velocity
    g: Math.round(100 * t),           // greener midrange
    b: Math.round(255 * t),           // bluer at high velocity
  };
}


function memory() {
  // Stop previous listener if active
  if (window.activeLiveListener) {
    window.activeLiveListener.postMessage("stop");
    window.activeLiveListener.terminate();
    window.activeLiveListener = null;
  }

  const noteToLedMap = new Map(); // MIDI → { led, color }

  const listener = new Worker("/static/js/listenWorker.js", { type: "module" });
  window.activeLiveListener = listener;
  listener.postMessage("start");

  listener.onmessage = function(event) {
    const notesHeld = event.data;

    const currentlyHeld = new Set(notesHeld.map(e => e.note));

    // Light up new notes
    for (const { note, velocity } of notesHeld) {
      if (!noteToLedMap.has(note)) {
        const ledEntry = mapNotesLeds.find(e => e.midi_note === note);
        if (ledEntry) {
          const brightness = velocity / 127; // normalize 0–1
          const baseColor = getRandomRGB();
          const scaledColor = {
            r: Math.round(baseColor.r * brightness),
            g: Math.round(baseColor.g * brightness),
            b: Math.round(baseColor.b * brightness)
          };

          noteToLedMap.set(note, { led: ledEntry.led_index, color: scaledColor });
          // turnLedOn([[ledEntry.led_index, scaledColor]]);
          memoryTrail(note);
        }
      }
    }

    // Fade out released notes
    for (const [note, { led, color }] of noteToLedMap.entries()) {
      if (!currentlyHeld.has(note)) {
        noteToLedMap.delete(note);
        fadeLedToBlack(led, color);
      }
    }
  };

  console.log("🎹 Live velocity play mode enabled!");
}

// 🧠 4. Memory Trail
// Each note leaves a glowing trail that slowly fades:
//     New notes leave stronger trails.
//     Visually shows your performance flow over time.
//Memory_Trail_Map is not defined
function memoryTrail(note) {
  const entry = mapNotesLeds.find(e => e.midi_note === note);
  if (!entry) return;

  const index = entry.led_index;

  // Create a new random color for this note
  const color = getRandomRGB();

  // Add to persistent trail map
  Memory_Trail_Map.set(index, color);

  // Immediately show the color
  turnLedOn([[index, color]]);

  // Begin slow fade out
  let step = 0;
  const steps = 30;
  const interval = 50;

  const fadeInterval = setInterval(() => {
    if (!Memory_Trail_Map.has(index)) {
      clearInterval(fadeInterval);
      return;
    }

    const current = Memory_Trail_Map.get(index);
    const fadeFactor = 1 - step / steps;
    const fadedColor = {
      r: Math.round(current.r * fadeFactor),
      g: Math.round(current.g * fadeFactor),
      b: Math.round(current.b * fadeFactor),
    };

    turnLedOn([[index, fadedColor]]);
    step++;

    if (step >= steps) {
      turnLedOff([index]);
      Memory_Trail_Map.delete(index);
      clearInterval(fadeInterval);
    }
  }, interval);
}
