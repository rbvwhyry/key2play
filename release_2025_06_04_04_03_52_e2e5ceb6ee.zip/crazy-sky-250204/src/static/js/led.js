// console.log("🥂🥖led.js");

import { cntMaxLeds } from "./global.js";

export async function fillStrip(Color) {
  console.log("🌰filling strip with ", Color);

  try {
    const Response = await fetch("/api/set_all_lights", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "color=" + JSON.stringify(Color)
    });

    const Data = await Response.json();

    if (Data.success) console.log("🐄all lights updated to ", Color);
    else console.error("⚠️error updating lights");

    await new Promise(res => setTimeout(res, 50)); // OPTIONAL: small delay to allow physical LED display to catch up
  } catch (error) {
    console.error("❌request failed:", error);
  }
}




export function turnLedOn(lightInstance) { //will turn lights on immediately
  // console.log("\n🌯turning on...");
  // console.debug("🥓light instance: " + JSON.stringify(lightInstance));

  fetch("/api/set_many_lights", { //setting the key:value, midi:index strip
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "lights=" + encodeURIComponent(JSON.stringify(lightInstance))
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // console.log("🐷some lights updated!");
    } else {
      console.error("⚠️ Error setting lights.");
    }
  })
  .catch(error => {
    console.error("❌ Request failed:", error);
  });
}

export function turnLedOff(indices) { //will turn lights off immediately
  // console.log("\n🐕‍🦺turning off indices: " + indices);

  fetch("/api/off_many_lights", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "indices=" + encodeURIComponent(JSON.stringify(indices))
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // console.log("🐺some lights off!");
    } else {
      console.error("⚠️ Error offing lights.");
    }
  })
  .catch(error => {
    console.error("❌ Request failed:", error);
  });
}

export async function reliableTurnLedOn(ledArray, retries = 3, delayMs = 30) {
  for (let attempt = 0; attempt < retries; attempt++) {
    turnLedOn(ledArray);

    // Brief delay between retries
    if (attempt < retries) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}

//1 large rainbow sweep
export function playRainbowAnimation() {
  const delayBetween = 2; // delay in ms between each LED lighting up

  // Convert hue (0–360) to {r, g, b}
  function hsvToRgb(h, s = 1, v = 1) {
    let f = (n, k = (n + h / 60) % 6) =>
      v - v * s * Math.max(Math.min(k, 4 - k, 1), 0);
    return {
      r: Math.round(f(5) * 255),
      g: Math.round(f(3) * 255),
      b: Math.round(f(1) * 255),
    };
  }

  // Light up one LED at a time with correct color
  for (let i = 0; i < cntMaxLeds; i++) {
    setTimeout(async () => {
      const hue = (i / (cntMaxLeds - 1)) * 270; // 0 = red, 270 = deep indigo
      const color = hsvToRgb(hue);
      await reliableTurnLedOn ([[i, color]]);
    }, i * delayBetween);
  }

  // Optional: turn off all LEDs after full rainbow is shown + delay
  setTimeout(() => {
    const all = [...Array(cntMaxLeds).keys()];
    turnLedOff(all);
  }, cntMaxLeds * delayBetween + 8000);
}