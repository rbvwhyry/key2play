// console.log("🥬🧄anim.js");

import { getLightColor } from "./color.js";
import { isBgrndAnim, KEYS_BLK,
   nodesShapeKeySWhite,
   cntClick, updateCountClick, nodesArrayIconS, TEXT_DYNAMIC, nodesShapeKeyS, control } from "./global.js";
import { setKeyClicks, resetElements } from "./piano.js";

let timelineOut;

export function scrollToCont(Id_Container) { //the content and animation is just 1 line, but it's easier to make them all consistent from here
  console.log("🥟scrolling to container ", Id_Container);

  gsap.to(window, { scrollTo:Id_Container, duration:1, ease:"power2.out" });
}




export function animateBgrndColors() {
    // console.log("🫐animating background colors...");

    if (isBgrndAnim) {
        gsap.to("#piano", { backgroundColor:getLightColor(), duration:2, ease:"power2.inOut", delay:2,
        onComplete: () => { gsap.delayedCall(3, animateBgrndColors); }, //wait 3s before looping
        });
    }
}

export function swingKeysIn() { //keys start out with the tapered shape and then swing into the normal shape, with some elasticity in easing
    console.log("🍹swinging keys in...");

    let timelineIn = gsap.timeline();

    timelineIn
      .to( KEYS_BLK, { duration:3, stroke:"black", strokeWidth:3, opacity:1, ease:"elastic.out(0.75, 0.1)",
        overwrite: "auto", // Cancels old animations on the same element
        attr: { d: (i, target) => target.getAttribute("d-norm") }, //faster than "morphSVG:"?
        stagger: { each: gsap.utils.random(0.1, 0.4), from: "random" }, //"each" more appropriate than "amount"; "from can be "start/end/center/edges/random"
      })
      .to( nodesShapeKeySWhite, { duration:4.5, stroke:"black", strokeWidth:3, opacity:1, ease:"elastic.out(0.75, 0.1)", overwrite:"auto",
          attr: { d: (i, target) => target.getAttribute("d-norm") },
          onUpdate: function () { //somewhere in the middle of the animation, setKeyClicks()
            const PROGRESS = this.progress(); //get animation progress (0 to 1) - apparently is inherent data to gsap
            // if (PROGRESS <= 0.3) console.log("🚀progress: " + PROGRESS);
            if (PROGRESS > 0.3 && !this.triggered) {
              console.log(`⌛Almost done! Running this at ${PROGRESS * 100}% progress...`);

              this.triggered = true; // Prevent multiple triggers
              setKeyClicks(); //<----- KEYS COLORS AND CLICK START HERE
            }
          },
          stagger: { each:gsap.utils.random(0.1, 0.4), from:"random" },
        }, "<10%"
      ); //white keys should enter in after black keys do
}

export function animateKeyPress(key) {
    // console.log(`🍅animating key press...`);

    const PATH_TAPER_SLIGHT = key.getAttribute("d-taper-slight");
    const PATH_FLARE = key.getAttribute("d-flare");
    const PATH_NORM = key.getAttribute("d-norm");

    gsap.timeline()
      .to( key, { morphSVG: PATH_TAPER_SLIGHT, duration: 0.22 })
      .to( key, { morphSVG: PATH_FLARE, duration: 0.45 }, ">")
      .to( key, { morphSVG: PATH_NORM, duration: 1, ease: "elastic.out(1,0.5)" }, ">");
}

export function animateIcon(key) { //see which key was pla
    console.log("🥝animating icon...");

    timelineOut = gsap.timeline();
    timelineOut.addLabel("start", 0).addLabel("next", 4);
    let icon, pathThic; //, pathThin; //specific to the main icon only

    console.log("🍉countClick: " + cntClick);
    // countClick = 0;
    updateCountClick(0);
    console.log("🧋countClick: " + cntClick);

    key === document.getElementById(`c4-path`) ? (icon = document.getElementById("settings-path")) :
    key === document.getElementById(`f4-path`) ? (icon = document.getElementById("light-path")) :
    (icon = document.getElementById("music-path")); //last key is `b4-path`

    pathThic = icon.getAttribute("d-thic"); //get thic shape

    const ARR_ICONS_REMAIN = nodesArrayIconS.filter((item) => item !== icon); //the other 2 icons

    timelineOut
      .to( ARR_ICONS_REMAIN, { duration:3, fill:"white" }, "start") //whiten other 2 icons -> LATER: will need to be blackened
      .to( ARR_ICONS_REMAIN, { duration:1, opacity:0 }, ">") //clear other 2 icons

      .to( icon, { duration:1, scale:0.07, repeat:1, yoyo:true, ease:"bounce.in" }, "start") //scale up from 0.04 and back
      .to( icon, { duration:1, morphSVG:pathThic }, "<") //change to thic shape -> LATER: will need to be thinned
      .to( icon, { duration:1, fill:getLightColor, stroke:"black", strokeWidth:70 }, "<") //give it a stroke and color -> LATER: will need to be unfilled, unstroked

      .to(icon, { duration:1, opacity:0 }, "next"); //clear main icon

    if (key === document.getElementById(`c4-path`)) { //if settings key, rotate
      console.log("🌽animating settings icon then scrollin* ...");

      timelineOut.to( icon, { rotate:gsap.utils.snap(180, gsap.utils.random(360, 1800)), duration:3, ease:"power2.out" }, "start"); //spin

      gsap.to( window, { scrollTo:"#cont-1-0", duration:1, ease:"power2.out" }); //move to correct container
    } else if (key === document.getElementById(`f4-path`)) { //if light key, bounce and turn on
      console.log("🍆animating light icon then scrolling...");

      timelineOut
        .to( icon, { yPercent:gsap.utils.random(-8, -4), duration:0.5, ease:"power2.out" }, "start")
        .to( icon, { yPercent:0, duration:gsap.utils.random(0.5, 1), ease:"bounce.out(2,0.01)" }, ">");

      gsap.to( window, { scrollTo:"#cont-2-0", duration:1, ease:"power2.out" }); //move to correct container
    } else if (key === document.getElementById(`b4-path`)) { //if music key, swing
      console.log("🥥animating music icon then scrolling...");

      timelineOut
        .to( icon, { rotate:gsap.utils.random(25, 50), duration: 0.3, ease: "power.out" }, "start")
        .to( icon, { rotate:0, duration:5, ease:"elastic.out(1.1, 0.08)" }, ">");

      gsap.to( window, { scrollTo:"#cont-3-0", duration:1, ease:"power2.out" }); //move to correct container
    }
}

export function animateOut() { //MOST exiting animations under 1 umbrella - except for the icons
  console.log("🥤animating out...");

  const DUR = 0.5;

  /* 0th icon already animated prior to this function being called
    white keys will colorize and fade out after 0th icon is clicked
    animating things out: */
  /* coherent top bar strategy:
    bar-top moves down
    bar-in keeps the children tighter together
    icon bounces in
    back <- && text -> */
  timelineOut
    .to(nodesShapeKeySWhite, { duration:1, stroke:"white", stagger:0.1 }, "start") //white key borders whiten; staggered in order

    .to(nodesShapeKeyS, { duration:0.5, opacity:0, stagger: { each:0.1, from:"random" }}, ">") //keys fade; staggered randomly

    .to("#bar-top", { duration:1, y:0, ease:"power2.out" }, "next") //black bar moves down
    // .fromTo("#emoji-right", { opacity:0, scale:0 }, { duration:1, scale:1, opacity:1, ease:"bounce.out" }, "<") //icon bounces in
    // .fromTo("#emoji-left", { opacity:0, scale:0, x:50 }, { duration:DUR, x:0, scale:1, opacity:1 }, ">") //back path moves left
    // .fromTo("#text-dynamic", { opacity:0, x:-50 }, { duration:DUR, x:0, opacity:1 }, "<"); //text moves right
}

export function animateBack() { //animating from top bar back to keys
  console.log("🥫animating back...");

  gsap.timeline().to("#bar-top", { duration: 1, y: "-100%" }); //black bar moves up, out of sight

  control.abort(); //<----- ABORTING!!!

  resetElements();
  swingKeysIn();
}