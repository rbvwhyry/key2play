// console.log("🧃🍸color.js");

import { nodesShapeKeySWhite } from "./global.js";

export const Color_Black = { r:0, g:0, b:0 };

export function getLightColor() { //light in terms of tone and hue, not brightness
    // console.log("🧊getting light color...")

    const R = Math.floor(Math.random() * 106) + 150; //150-255
    const G = Math.floor(Math.random() * 106) + 150;
    const B = Math.floor(Math.random() * 106) + 150;
    return `rgb(${R}, ${G}, ${B})`;
}






export function colorKeys(colors) {
    // console.log("🍓coloring keys...");

    let fill = gsap.utils.random([gsap.utils.wrap(ARR_RAINBOW), getLightColor]); //fill is a random color array by default
    if (colors === "white") fill = colors; //if it's white, change fill value

    // gsap.to(KEYS_WHT, { fill: fill, stagger: 0.2 });
    gsap.to(nodesShapeKeySWhite, { fill: fill, stagger: 0.2 });

    if (colors !== "white") gsap.delayedCall(1.75, () => colorKeys("white")); //if keys aren't white, then make them white after secs, essentially clearing them
}

const ARR_RAINBOW = [ "#FFB3B3", "#FFD9B3", "#FFFFB3", "#B3FFB3", "#B3FFFF", "#B3B3FF", "#FFB3FF" ];


export function getRandomRGB() {
    return {
        r: Math.floor(Math.random() * 256),
        g: Math.floor(Math.random() * 256),
        b: Math.floor(Math.random() * 256)
    };
}




function getRandomColor() { //returns GRB (python) instead of RGB (js)
    return {
        g: Math.floor(Math.random() * 256),
        r: Math.floor(Math.random() * 256),
        b: Math.floor(Math.random() * 256)
    };
}


export const Purple_Color = { r:255, g:0, b:255 };
export const Red_Color = { r:255, g:0, b:0 };