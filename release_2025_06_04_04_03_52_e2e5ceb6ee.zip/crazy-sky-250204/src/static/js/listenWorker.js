// console.log("🍾🥢listenWorker.js");

let isListening = false;

onmessage = function(event) {
    // console.log("🥘message event received...");

    if (event.data === "start") { //event.data is given by piano.js
        console.log("\n🍢start listening...");

        if (!isListening) {
            isListening = true;
            pollBackend(); //start listening
        }
    } else if (event.data === "stop") {
        console.log("\n🍪stop listening...");

        isListening = false;
    }
};

async function pollBackend() {
    // console.log("🥜polling backend...");

    console.log("🍞isListening: " + isListening);
    while (isListening) {
        let response = await fetch("/api/currently_pressed_keys");
        
        if (!isListening) break; //important that this line is located here and not above

        let data = await response.json(); //data is array

        // console.log("🍜response: " + response);
        // console.log("🥚data: " + data); //turn this on to see a stream of arrays
        
        self.postMessage(data); //from here, send everything to front-end to let it do the evaluating itself                
    }
}