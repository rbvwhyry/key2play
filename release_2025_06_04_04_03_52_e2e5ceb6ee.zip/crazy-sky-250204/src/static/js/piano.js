/* 
  remember to think about colorblind folks

  calibrate:
  - make sure each instance is never more than 1 key
  - make sure 2nd key must be higher than the 1st key
  - make sure number of keys is sufficient minimum (just warn user if their keyboard seems short)
  - turn on entire keyboard lights animation after confirm
  - calibrating is weird, at led 191?

  learn:
  - allow for user to adjust how far out from now to see future leds

  top bar:
  - text says ami, bounces down along with top bar, but randomized
  - bar stays down, every few seconds, text scrambles to something else, then back to ami
  - when a key is played, text appears on the key as well, so user knows what they be selecting
  - once key is played a 2nd time for selection, dynamic text scrambles into text that needs to go; back arrow appears
  - once back arrow is clicked, scramble text to "amigo", then ami; resumes scrambling every few seconds
*/

// console.log("🌶🦪🍦piano.js");

import { nodeBarTop, nodeTxtDynamic, Array_Ami_FriendS, nodesShapeKeyS, nodesArrayIconS, nodeTxtCalibRemind, //variables
  mapNotesLeds, Emojis,
  getKeysCalibrated, //get functions
  updateFromDom, updateIsBgrndAnim, updateCountClick, //set functions

  cntClick, getControl, setSignal, abortSignal, updateKeyboardFirstKey, updateKeyboardLastKey, getMapFromDatabase, updateMapNotesLeds } from "./global.js";
import { fillStrip } from "./led.js";
import { Color_Black, 
  colorKeys
 } from "./color.js";
import { animateBgrndColors,
   swingKeysIn, animateKeyPress, animateIcon, animateOut, animateBack } from "./anim.js";
import { scrollToCont } from "./anim.js";

import { playNote } from "./audio.js";
import { startCalibrating } from "./calibrate.js";
import { startLearning } from "./learn.js";
import { startPlaying } from "./play.js";

let textDynamic;

document.addEventListener("DOMContentLoaded", () => {
  document.fonts.ready.then(() => { //will help with gsap SplitText and so on
    // console.log("🍄dom loaded!");

    updateFromDom(); //do all get and set of dom elements here, once we know for sure dom has loaded; register gsap plug-ins too

    /* ----- ----- ----- ----- ----- DECLARING SHIT ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- */
    // console.log("🍿declaring shit..."); 

    /* ----- ----- ----- ----- ----- CALLING SHIT ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- */
    // console.log("🥗calling shit...");

    resetElements();
    animateBgrndColors(); //start loop
    start();
  });
});

/* ----- ----- ----- ----- ----- FUNCTIONING SHIT ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- */
  // console.log("🥣functioning shit...");

  export async function resetElements() {
    console.log("🍶resetting elements...");

    scrollToCont("#cont-0"); //to top

    gsap.set("#settings-path", { attr: { transform: "translate(50,250) scale(0) translate(-500,-500)" }}); //HTML equivalences
    gsap.set("#light-path", { attr: { transform: "translate(350,250) scale(0) translate(-500,-500)" }});
    gsap.set("#music-path", { attr: { transform: "translate(654,250) scale(0) translate(-500,-500)" }});

    await fillStrip(Color_Black); //turn leds off

    updateIsBgrndAnim(true); //resetting background

    nodesShapeKeyS.forEach((Key) => { //setting keys "d-path" so that they can swing forward to d-norm shape
      const D_Taper = Key.getAttribute("d-taper");
      Key.setAttribute("d", D_Taper);
    });

    // console.log("🍡countClick: " + countClick);
    updateCountClick(0);
    // console.log("🍙countClick: " + countClick);

    nodesArrayIconS.forEach((Icon) => {
      Icon.style.fill = "black";
      Icon.setAttribute("d", Icon.getAttribute("d-thin"));
      Icon.style.strokeWidth = "0";
      Icon.style.stroke = "none";
    });
  }

  let splitTxtCalibRemind;
  const Timeline_TxtCalibRemind = gsap.timeline();

  let Is_Keys_Calibrated
  async function start() { //all entering animations under 1 umbrella
    console.log("🫖starting...");

    /* elements that appear in from nothing may have 1 of 2 problems:
        - if css states that it's invisible, it may never appear in
        - if css says it is visible, it may flash in before disappearing programmatically
      when working with gsap, especially with splittext, it may break the illusion;
      so this is the algorithm:
        - set element css as visibility:hidden 
        - split element 
        - set split to hidden 
        - set element to visible (optional)
        - in animation, make split visible */

        Is_Keys_Calibrated = await getKeysCalibrated(); //when if(Is_Keys_Calibrated) follows, then await here is not optional
        console.log("🐍Is_Keys_Calibrated:", Is_Keys_Calibrated);

        if (Is_Keys_Calibrated) {
          const Map = await getMapFromDatabase();
          updateMapNotesLeds(Map)
          // console.log(`🌸mapNotesLeds:`, mapNotesLeds);
          
          //set first last keys here
          const Notes = Map.map(entry => entry.midi_note);
          const Min_Midi = Math.min(...Notes);
          const Max_Midi = Math.max(...Notes);
          // console.log("🐫Min_Midi:", Min_Midi, "🍫Max_Midi:", Max_Midi);
          
          updateKeyboardFirstKey(Min_Midi);
          updateKeyboardLastKey(Max_Midi);
        }

    swingKeysIn(); //onUpdate: setKeyClicks

    dropBarDown();

    scramble(); //onComplete: descramble
  }

    const Timeline_BarTop = gsap.timeline();
    function dropBarDown() {
      Timeline_BarTop.from(nodeBarTop, { delay:2, duration:2, y:'-100%', ease:"elastic.out(1, 0.25)" //bounce effect: amplitude (+ is wilder), period (- is wilder)
      }, 'start');

      Timeline_BarTop.to({}, { duration:2 }); //anim wait 2s

      Timeline_BarTop.from(nodeTxtDynamic, { delay:2, duration:2, y:'-100%', ease:"elastic.out(1, 0.25)" //bounce effect: amplitude (+ is wilder), period (- is wilder)
      }, 'start');




    //         // 🎯 Setup
    //   const finalText = "ami";
    //   const scrambleCount = 5;
    //   let array = scrambleTxtDynamic(scrambleCount);
      
    //   // 💡 Add fake scrambles
    //   for (let i = 0; i < scrambleCount; i++) {
    //     const tempText = array;
    //     Timeline_BarTop.to(nodeTxtDynamic, {
    //       duration: 1.5,
    //       scrambleText: {
    //         text: tempText,
    //         chars: "ami",
    //         revealDelay: 0.2,
    //         speed: 0.2
    //       },
    //       ease: "power1.inOut"
    //     }, '>');
    //   }
      
    //   // ✅ Final correct text
    //   Timeline_BarTop.to(nodeTxtDynamic, {
    //     duration: 2,
    //     scrambleText: {
    //       text: finalText,
    //       chars: "ami",
    //       revealDelay: 0.5,
    //       speed: 0.3
    //     },
    //     ease: "power2.out"
    //   });
    // }


      
      Timeline_BarTop.to(nodeTxtDynamic, { duration:4, //duration is what is used to calculate onComplete
        scrambleText: {
          text:'ami', chars:'ami', revealDelay:2, speed:0.1, //lower is faster scramble refresh
        }, //ease:"power2.inOut", //starts & ends slow, middle fast
        onComplete: () => {
        }
      }, '>0.5');
    }


      //https://gsap.com/docs/v3/GSAP/UtilityMethods/random()/#2-randomarray-returnfunction
      function scrambleTxtDynamic(Count_Repetitions) {
        let random = gsap.utils.random(Array_Ami_FriendS, true); //'true' returns random as a function instead of a var and lets us call it multiple times
        let array = [];

        for (let i = 0; i < Count_Repetitions; i++) {
          array.push(random());
        }
        console.log('array:', array);

        return array;
      }







    let textOld, textOldLength;
    function scramble() {
      textOld = nodeTxtCalibRemind.innerHTML; //asks 'calibrated?'
      textOldLength = countGraphemes(textOld);
      // console.log(`textOld: `, textOld);
      // console.log(`textOldLength: `, textOldLength);

      splitTxtCalibRemind = new SplitText(nodeTxtCalibRemind, { type:"chars" });

      gsap.set(splitTxtCalibRemind.chars, {
        visibility:"hidden", scale:0
      });

      gsap.set(nodeTxtCalibRemind, {
        visibility:"visible"
      });

      //bounce chars in
      Timeline_TxtCalibRemind.to(splitTxtCalibRemind.chars, { duration:1.5, visibility:"visible", scale:1,
        stagger: {
          each:0.1, from:"random",
        }, ease:"elastic.out(1.5, 0.2)" //bounce effect: amplitude (+ is wilder), period (- is wilder)
      }, 'start');

      Timeline_TxtCalibRemind.to({}, { duration:2 }); //anim wait 2s b4 scrambling so user can read og text

      const Random_Scramble = getRandomScramble(Emojis, textOldLength);
      // console.log(`Random_Scramble: `, Random_Scramble);

      //will scramble from right to left; loop counts down from length to zero
      for (let i = (textOldLength-1); i >= 0; i--) { //i is index inside html text
        Timeline_TxtCalibRemind.to(splitTxtCalibRemind.chars[i], { duration:(i+2)/2, //duration is what is used to calculate onComplete
          scrambleText: {
            text:Random_Scramble[i], chars:Emojis, revealDelay:(i)/2, speed:0.1, //lower is faster scramble refresh
          }, ease:"power2.inOut", //starts & ends slow, middle fast
          onComplete: () => { //when complete, the scramble will have the same length as the old text
            if (countDescramble === 0) descramble(); //bc it's a loop, this gets called multiple times!!! once per grapheme; make sure we only descramble once
          }
        }, '<0.5'); //since each following grapheme has a duration that's 1 less per iteration (b/c duration is based on i, which is based on the length of the og text), we start the animation 1 second after the prev; this way the first and last graphemes will all end at the same time
      }
    }

      function countGraphemes(input) {
        const segmenter = new Intl.Segmenter("en", { granularity: "grapheme" });
        const graphemes = Array.from(segmenter.segment(input), s => s.segment);
        return graphemes.length;
      }

      //note: one random scramble may feature repeat content
      function getRandomScramble(input, length) {
        const segmenter = new Intl.Segmenter("en", { granularity: "grapheme" });
        const graphemes = Array.from(segmenter.segment(input), s => s.segment);
      
        // Shuffle
        for (let i = graphemes.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [graphemes[i], graphemes[j]] = [graphemes[j], graphemes[i]];
        }
      
        // return graphemes.slice(0, length).join(''); //returns a string
        return graphemes.slice(0, length); //returns array of graphemes
      }

  // const Is_Keys_Calibrated = await getKeysCalibrated(); //when if(Is_Keys_Calibrated) follows, then await here is not optional
  // console.log("🐍Is_Keys_Calibrated:", Is_Keys_Calibrated);
  // if (Is_Keys_Calibrated) {
  //   const Map = await getMapFromDatabase();
  //   updateMapNotesLeds(Map)
  //   // console.log(`🌸mapNotesLeds:`, mapNotesLeds);
    
  //   //set first last keys here
  //   const Notes = Map.map(entry => entry.midi_note);
  //   const Min_Midi = Math.min(...Notes);
  //   const Max_Midi = Math.max(...Notes);
  //   // console.log("🐫Min_Midi:", Min_Midi, "🍫Max_Midi:", Max_Midi);
    
  //   updateKeyboardFirstKey(Min_Midi);
  //   updateKeyboardLastKey(Max_Midi);
  // }

    let countDescramble = 0;
    async function descramble() {
      countDescramble++; //we only want this function to run once

      let textNew, textNewLength, lengthDifference; //length difference is how many iterations we take in the following loop

      if (Is_Keys_Calibrated === false) textNew = '🎹needs calibration🤔👉 | try ⚙️Settings';
      else textNew = '🎹calibrated🥰👍';
      textNewLength = countGraphemes(textNew);
      lengthDifference = textNewLength - textOldLength; //if difference is +, we add more emojis; if -, we subtract
      // console.log(`finalText: ${textNew}`);
      // console.log(`finalTextLength: ${textNewLength}`);
      // console.log(`lengthDifference: ${lengthDifference}`);

      for (let i = 0; i < lengthDifference; i++) { //how would this work if new text is shorter (ie, if lengthDifference were negative)?; we don't need to fix anything at this point, but if new text is ever shorter, we need to take this part into account
        const New_Length = textOldLength + i;
        const New_Scramble = getRandomScramble(Emojis, New_Length);
        // console.log("New_Length:", New_Length);
        // console.log("New_Scramble:", New_Scramble);

        nodeTxtCalibRemind.innerHTML = New_Scramble.join(''); //join to make array into a string

        await sleep(300); //wait 0.3s
      }

      //descrambling
      Timeline_TxtCalibRemind.to(nodeTxtCalibRemind, { duration:5, //duration is what is used to calculate onComplete
        scrambleText: {
          text:textNew, chars:Emojis, revealDelay:2, speed:0.75, //lower is faster scramble refresh
        },
        onComplete: () => { //if already calibrated, disappear it after a while; if not, leave reminder on
          if (Is_Keys_Calibrated) {
            splitTxtCalibRemind = new SplitText(nodeTxtCalibRemind, { type:"chars" }); //resplit after text change on og text, otherwise, there's nothing for timeline to latch onto

            Timeline_TxtCalibRemind.to(splitTxtCalibRemind.chars, { duration:1.5, opacity:0,
              stagger: {
                each:0.1, from:"random",
              }
            }, '>5'); //wait 5s before vanishing
          }
        },
      });
    }

      function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
      }
      




  /* ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- */

    export function setKeyClicks() { //plays notes, animate keys, color keys, counts clicks
      console.log("🍺setting key clicks...");

      colorKeys(); //run colors once so ppl know that keys are pressable now

      getControl(); //new instances allows for us to abort multiple times
      setSignal(); //so we know when/where to cancel them later

      textDynamic = document.getElementById("text-dynamic");

      nodesShapeKeyS.forEach((key) => {
        key.style.pointerEvents = "auto"; //actually lets the things be buttons and clickable
        key.style.cursor = "pointer"; //visually lets folks know the keys are now clickable (using pointer; then color keys)

        key.addEventListener( "click", () => { //on key click we 1) play sound, 2) animate key movement, 3) color white keys
          // console.log("🍑key:" + key);
          const NOTE = key.id.replace("-path", "-audio");
          // console.log("🥑NOTE:" + NOTE);
          
          playNote(NOTE);
          animateKeyPress(key);
          colorKeys();

          console.log("🍎countClick: " + cntClick);

          if (cntClick == 0) { //show icon now
            console.log("🫑showing icons...");
            
            nodesArrayIconS.forEach((icon) => gsap.fromTo( icon, { opacity:0, scale:0 }, { scale:0.04, opacity:1, duration:3, transformOrigin:"center", ease:"elastic.out(0.5, 0.1)" })); //make icons larger
          }
          else { //see if we should morph an icon
            const KEYS_TO_MATCH = ["c4-path", "f4-path", "b4-path"];
            if (KEYS_TO_MATCH.includes(key.id)) {
              console.log("🫒a key matched!");

              nodesShapeKeyS.forEach((key) => {
                key.style.cursor = "default"; //change cursor to nothing -> LATER: will need to be "hand cursor"
                key.style.pointerEvents = "none"; //disable click interactions -> LATER: will need to be "auto"
              });

                animateIcon(key); //animate this 1 icon; <--- here we also animate window move to correct container
                animateOut();

                if (key === document.getElementById(`c4-path`)) { //if settings key
                  textDynamic.textContent = "settings";
                  setSettingsClick(); //calibrate buttons and the such
                } else if (key === document.getElementById(`f4-path`)) { //if light key
                  textDynamic.textContent = "learn";
                  setLearnClick(); //learn songs, chords, scales, and more
                } else if (key === document.getElementById(`b4-path`)) { //if music key        
                  textDynamic.textContent = "play";
                  setPlayClick(); //play with reactive lights
                }
            }
          }

          updateCountClick(cntClick+1)

        }, { signal: abortSignal }); //<----- TO KNOW WHAT EVENT TO REMOVE
      });

      document.getElementById("icon-left").addEventListener( "click", () => { //clicking BACK will withdraw #top-bar and re-swing in the keys
          console.log("🧂going back...");

          animateBack();
      }, { signal: abortSignal }); //<----- TO KNOW WHAT EVENT TO REMOVE
    }

      function setSettingsClick() {
        console.log("🍋setting settings click...");

        document.getElementById("btn-calibrate").onclick = function() { //using onclick will allow for self-erasing and no chance of doubling up, and no need for canceling a previous call
          gsap.to( window, { scrollTo:"#cont-1-1", duration:1, ease:"power2.out",
            onComplete: () => {
              startCalibrating(); //starts the calibration loop
            },
          }); //move to correct container
        }
      }

      function setLearnClick() {
        console.log("🐶setting learn click...");

        startLearning(); //starts the learning loop
      }

      function setPlayClick() {
        console.log("🦟setting play click...");

        startPlaying(); //starts the playing loop
      }

/* SHOW LIVE DIMENSIONS
function updateDimensions() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const dpr = window.devicePixelRatio;
    
    // Convert to various units
    const vw = width / 100;
    const vh = height / 100;
    const emBase = parseFloat(getComputedStyle(document.documentElement).fontSize);
    const remBase = parseFloat(getComputedStyle(document.documentElement).fontSize);
    
    // Calculate physical units (approximate)
    const dpi = 96 * dpr; // Standard CSS pixel density * device pixel ratio
    const inchWidth = width / dpi;
    const inchHeight = height / dpi;
    const cmWidth = inchWidth * 2.54;
    const cmHeight = inchHeight * 2.54;
    const mmWidth = cmWidth * 10;
    const mmHeight = cmHeight * 10;
    
    // Update display
    document.getElementById('px').innerHTML = `
        Pixels: ${width}px × ${height}px<br>
        Device Pixel Ratio: ${dpr}
    `;
    
    document.getElementById('vh-vw').innerHTML = `
        Viewport: ${width/vw}vw × ${height/vh}vh<br>
        Units: 1vw = ${vw.toFixed(2)}px, 1vh = ${vh.toFixed(2)}px
    `;
    
    document.getElementById('percent').innerHTML = `
        Percentage: 100% × 100%<br>
        1% = ${(width/100).toFixed(2)}px × ${(height/100).toFixed(2)}px
    `;
    
    document.getElementById('em-rem').innerHTML = `
        Em/Rem: ${(width/emBase).toFixed(2)}em × ${(height/emBase).toFixed(2)}em<br>
        1em/rem = ${emBase}px
    `;
    
    document.getElementById('cm-mm-in').innerHTML = `
        Physical: ${cmWidth.toFixed(2)}cm × ${cmHeight.toFixed(2)}cm<br>
        ${mmWidth.toFixed(2)}mm × ${mmHeight.toFixed(2)}mm<br>
        ${inchWidth.toFixed(2)}in × ${inchHeight.toFixed(2)}in
    `;
}

// Update on load and resize
window.addEventListener('load', updateDimensions);
window.addEventListener('resize', updateDimensions);

// Update every second for dynamic changes
setInterval(updateDimensions, 1000);
*/

function generateGrid() {
  const gridContainer = document.getElementById('cont-1-1');
  
  // Clear any existing items
  gridContainer.innerHTML = '';
  
  // // Calculate optimal grid layout
  // const { columns, rows } = calculateOptimalGrid();
  
  // // Set CSS variables for the grid layout
  // gridContainer.style.setProperty('--columns', columns);
  // gridContainer.style.setProperty('--rows', rows);
  
  // Create a fragment to avoid multiple reflows
  const fragment = document.createDocumentFragment();
  
  // Create 200 grid items
  for (let i = 1; i <= 200; i++) {
      const gridItem = document.createElement('div');
      gridItem.className = 'grid-item';
      gridItem.textContent = i;
      


      //grid item needs to be distinguishable and each needs to be clickable




      // Add varying brightness for visual interest
      const brightness = 0.7 + (Math.random() * 0.6);
      gridItem.style.setProperty('--brightness', brightness);
      
      fragment.appendChild(gridItem);
  }
  
  // Append all items at once
  gridContainer.appendChild(fragment);
  
  // Use GSAP for a staggered appearance
  gsap.from('.grid-item', { duration:0.8, opacity:0, scale:0, y:20, ease:"back.out(1.7)",
      stagger: { amount:2, from:"random",
          // grid: [rows, columns],
      }
  });
}

// Find the optimal grid dimensions for 250 elements
function calculateOptimalGrid() {
  const totalItems = 250;
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const aspectRatio = viewportWidth / viewportHeight;
  
  // Calculate optimal columns and rows to maintain aspect ratio
  let columns = Math.round(Math.sqrt(totalItems * aspectRatio));
  let rows = Math.ceil(totalItems / columns);
  
  // Ensure we have exactly enough cells for all elements
  while (columns * rows < totalItems) {
      columns++;
  }
  
  return { columns, rows };
}