// console.log("🥕🍬audio.js");

export function playNote(note) {
  console.log(`🥦playing ${note}...`);

  const AUDIO = document.getElementById(note);

  if (AUDIO) {
    AUDIO.volume = 0.25; //lower volume
    AUDIO.currentTime = 0; // Reset sound for quick retriggering
    AUDIO.play().catch((error) =>
      console.error("🥔Audio play failed:", error)
    );
  }
}