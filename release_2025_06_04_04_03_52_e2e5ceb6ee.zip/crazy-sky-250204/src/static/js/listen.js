// console.log("🍳🍨listen.js");

import { setFirstKey, setLastKey } from "./calibrate.js";

export function listenForKey(keyToAssign) {
  console.log("🍊listening for " + keyToAssign + " key...");
  
  let played = { note:0, velocity:0 }; //can't leave it undefined
  let isOneNote = false; //has 1 singular key been hit yet?

  const listener = new Worker("/static/js/listenWorker.js", { type:"module" });
  listener.postMessage("start");
  listener.onmessage = function(event) {
    let arrNotesPlayed = event.data; //an array of objects {note, velocity}
    let cntNotesPlayed = arrNotesPlayed.length;
    // console.log("🥠count of notes played: " + cntNotesPlayed); //length of array is how 

    if (cntNotesPlayed === 1) { //ignore multiple keys here
      // console.log("🍵1");

      played = arrNotesPlayed[0];
      isOneNote = true;

    } else if (isOneNote) { //0/2+ keys is implied here from the if statement above
      // console.log("🥭0/2+");

      listener.postMessage("stop");

      if (cntNotesPlayed === 0) { //what to do when key is released (count = 0); register
        console.log("🫓played: " + played);
        console.log("🥠count of notes played: " + cntNotesPlayed);

        let note = played.note;
        console.log("\n🥞note: " + note);
        console.log("🧆velocity: " + played.velocity);

        if (keyToAssign === "first") {
          // console.log("🍰first key DONE");
          setFirstKey(note);
        } else if (keyToAssign === "last") {
          // console.log("🫔last key DONE");
          setLastKey(note);
        }
      } else { //what to do when another key is pressed (count = 1+); ignore?; tell the user to try again
        //STILL HAS TO DO SHIT HERE
      }
    }

    //document.querySelector('.AsPopup-popup-overlay').remove(); //library doesn't provide a removal method

    // console.log("🍒keyboardFirstKey0: " + keyboardFirstKey);
    // console.log("🥡keyboardLastKey0: " + keyboardLastKey);
  }
  
  listener.onerror = function(event) {
    console.error("🍘Worker error:", event);
    console.error("🍔Error message:", event.message);
    console.error("🫕Error filename:", event.filename);
    console.error("🍠Error line number:", event.lineno);
  };
}