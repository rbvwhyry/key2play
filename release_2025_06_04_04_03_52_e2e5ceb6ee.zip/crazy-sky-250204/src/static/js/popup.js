// console.log("🍚🍛popup.js");

import { keyboardFirstKey, keyboardLastKey, updateKeyboardFirstKey, updateKeyboardLastKey, keyboardKeyCount, updateKeyCount } from "./global.js";
import { scrollToCont } from "./anim.js";
import { turnLedOn, fillStrip } from "./led.js";
import { getRandomRGB } from "./color.js";

export function popCalibrate() {
  console.log("🍩popping calibrate...");
  
  as.popup({
    background: "rgba(255,255,255,3)",
    title: "Calibrate",
    text: `'Continue' to begin calibrating this light bar to your piano keyboard.
    'Cancel' at anytime to return to the settings menu.`,
    closeBtn: false,
    overlayClick: false, //won't close popup if user clicks outside
    buttons: [
      { html:"Cancel", color:"black", bg:"#E5E4E2",
        click:function(){
          scrollToCont("#cont-1"); // gsap scroll back to previous container
          //REMEMBER to clear the grid after canceling
        }
      },
      { html:"Continue", color:"white", bg:"#6CB4EE",
        click:function(){
          popFirstKey(); //open next popup
        }
      }, //continue to get first and last keyboard keys 
    ]
  });
}

export function popFirstKey() {
  console.log("\n🍝popping first key...");

  as.popup({
    background: "rgba(255,255,255,5)",
    title: "First Key",
    text: "Play the first key on your keyboard.",
    closeBtn: false,
    overlayClick: false, //won't close popup if user clicks outside
    buttons: [
      { html:"Cancel", color:"black", bg:"#E5E4E2",
        click:function(){
          scrollToCont("#cont-1"); // gsap scroll back to previous container
        }
      },
    ]
  });

  listenForKey("first");
}

export function popLastKey() {
  console.log("\n🥜popping last key...");

  //updateKeyboardKey(element, keyboardKey) //set universal first key
  
  as.popup({
    background: "rgba(255,255,255,15)",
    title: "Last Key",
    text: "Play the last key on your keyboard.",
    closeBtn: false,
    overlayClick: false, //won't close popup if user clicks outside
    buttons: [
      { html:"cancel", color:"black", bg:"#E5E4E2",
        click:function(){
          scrollToCont("#cont-1"); // gsap scroll back to previous container
        }
      },
    ]
  });

  listenForKey("last");
}

//remember to filter out multiple keys, or if 2nd key is in front of 1st key

function listenForKey(keyToAssign) {
  console.log("🍊listening for " + keyToAssign + " key...");
  
  let played = { note:0, velocity:0 }; //can't leave it undefined
  let isOneNote = false; //has 1 singular key been hit yet?

  const listener = new Worker("/static/js/listenWorker.js", { type:"module" });
  listener.postMessage("start");
  listener.onmessage = function(event) {
    let arrNotesPlayed = event.data; //an array of objects {note, velocity}
    let cntNotesPlayed = arrNotesPlayed.length;
    // console.log("🥠count of notes played: " + cntNotesPlayed); //length of array is how 

    if (cntNotesPlayed === 1) { //ignore multiple keys here
      // console.log("🍵1");

      played = arrNotesPlayed[0];
      isOneNote = true;

    } else if (isOneNote) { //0/2+ keys is implied here from the if statement above
      // console.log("🥭0/2+");

      listener.postMessage("stop");

      if (cntNotesPlayed === 0) { //what to do when key is released (count = 0); register
        // console.log("🫓played: " + played);

        let note = played.note;
        console.log("🥞note: " + note);
        console.log("🧆velocity: " + played.velocity);

        if (keyToAssign === "first") {
          console.log("🍰first key DONE");
          updateKeyboardFirstKey(note);
          popLastKey();
        } else if (keyToAssign === "last") {
          console.log("🫔last key DONE");
          updateKeyboardLastKey(note);
          popLastLeds();
        }
      } else { //what to do when another key is pressed (count = 1+); ignore?; tell the user to try again
        //STILL HAS TO DO SHIT HERE
      }
    }



    //document.querySelector('.AsPopup-popup-overlay').remove(); //library doesn't provide a removal method

    // console.log("🍒keyboardFirstKey0: " + keyboardFirstKey);
    // console.log("🥡keyboardLastKey0: " + keyboardLastKey);

    
  }

  listener.onerror = function(event) {
    console.error("🍘Worker error:", event);
    console.error("🍔Error message:", event.message);
    console.error("🫕Error filename:", event.filename);
    console.error("🍠Error line number:", event.lineno);
  };
}

async function popLastLeds() {
  console.log("\n🐢popping last leds...");

  console.log("🥐keyboardFirstKey: " + keyboardFirstKey);
  console.log("🍧keyboardLastKey: " + keyboardLastKey);
  updateKeyCount();
  console.log("🎂keyboardKeyCount: " + keyboardKeyCount);
  
  // await fillStrip();
  //old turning on method
  // turnLedOn(317, getRandomRGB());
  // turnLedOn(318, getRandomRGB()); //last one for 2m, 160leds/m
  // turnLedOn(319, getRandomRGB());


  //new turning on method
  // const lights = [
  //   [10, [255, 0, 0]],  // light #0, red
  //   [11, [0, 255, 0]],  // light #1, green
  //   [12, [0, 0, 255]]   // light #2, blue
  // ];
  // turnLedOn(lights);

  await fillStrip(getRandomRGB());

  //turn on 1st led and start 
  
}