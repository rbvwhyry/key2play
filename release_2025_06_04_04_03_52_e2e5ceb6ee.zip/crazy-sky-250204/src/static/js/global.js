// console.log("🧉🍷global.js");

export let nodeBarTop, nodeTxtDynamic, nodesShapeKeyS, nodesShapeKeySWhite, nodeTxtCalibRemind; //node means we get from html document query
export let nodesArrayIconS = Array.from(document.querySelectorAll(".icon")); //nodelist -> array
export function updateFromDom() {
  gsap.registerPlugin(MorphSVGPlugin, ScrollToPlugin, ScrambleTextPlugin, SplitText);

  //despite getting imported by other js files 'right away', declaring their values here still works
  //not everything needs to be defined here, just globally used things
  nodeBarTop = document.getElementById('bar-top');
  nodeTxtDynamic = document.getElementById('text-dynamic');
  nodesShapeKeyS = document.querySelectorAll(".key");
  nodesShapeKeySWhite = document.querySelectorAll(".key.white");
  nodeTxtCalibRemind = document.getElementById('calibration-reminder');
}

export const Array_Ami_FriendS = [
  "ami",         // French: friend
  "amie",        // French (feminine): friend
  "amico",       // Italian: friend (masc.)
  "amica",       // Italian: friend (fem.)
  "amici",       // Italian plural: friends
  "amiga",       // Spanish/Portuguese: friend (fem.)
  "amigo",       // Spanish/Portuguese: friend (masc.)
  "amity",       // Latin root: friendship
  "amitié",      // French: friendship
  "amable",      // Spanish/French: kind, friendly
  "amabilis",    // Latin: lovable
  "amare",       // Latin: to love
  "amour",       // French: love
  "amando",      // Italian/Spanish: loving
  "amouré",      // French variant (rare): in love
  "amavi",       // Latin: I have loved
  "amicae",      // Latin: to/for the friend (fem.)
  "amiciæ",      // Latin (variant): of the friend
  "amizade",     // Portuguese: friendship
  "amicizia",    // Italian: friendship
  "amihan",      // Tagalog: wind from the east (poetic)
  "amígdala",    // Greek/Latin root: almond (brain/emotion context)
  "amicaal",     // Dutch: amicable
  "amice",       // archaic English: friend
  "amika",       // Esperanto: friendly
  "amike",       // Esperanto: in a friendly way
  "amikoj",      // Esperanto plural: friends
  "amiku",       // Japanese romaji: friend (phonetic)
  "amiya",       // Arabic: noble, beautiful
  "amihan",      // Filipino: seasonal wind (soothing/mystical)
  "amica",       // Romanian: female friend
  "amigoa",      // Basque: friend
  "amicy",       // Slavic stem-like construction
  "amisi",       // invented Swahili variant: friendship (not official)
  "amiko",       // Japanese katakana transliteration
  "amore",       // Italian: love
  "amira",       // Arabic/Hebrew: princess / leader
  "amid",        // Hebrew root: stand, support
  "amiraa",      // Somali: princess / grace
  "amihan",      // Philippine: breeze or wind
  "amina",       // Arabic: peaceful, honest
  "amine",       // Arabic/French: faithful/trustworthy
  "amim",        // Turkish: sincere
  "amicius",     // invented Latin blend
  "amipura",     // Sanskrit blend: pure friend
  "amihanen",    // constructed language style
  "amiela",      // poetic invented name (ami + bella)
  "amiciro",     // Slavic-influenced neologism
  "amiki",       // constructed from Esperanto style
  "amiram",      // Hebrew: exalted nation
  "amitie",      // old French: friendship
  "amikoro",     // Japanese-styled invented word
  "amixan",      // Basque-inspired neologism
  "amirati",     // constructed Slavic verb: to befriend
  "amichu",      // Quechua sounding variant (constructed)
  "amizuru",     // Japanese-Esperanto hybrid feel
  "aminah",      // Arabic: honest, trustworthy (fem.)
  "amavius",     // Romanesque name (I loved)
  "amiwara",     // poetic Sanskrit-style invention
  "amikata",     // Japanese-style hybrid: way of friend
  "amilek",      // invented Hebrew-flavored name
  "amisol",      // ami + sol (sun / sound)
  "aminoa",      // amino acid blend / friendly science twist
  "amithra",     // Mithra + ami (friend deity)
  "amithya",     // ami + mythic twist
  "amindra",     // ami + Indra (Hindu god)
  "amynah",      // phonetic variant of Amina
  "amiriel",     // elvish-inspired: ami + angel suffix
  "amihana",     // peaceful wind, fantasy-like
  "amikuru",     // Japanese-style suffix + friend
  "amimomo",     // playful Japanese-style invention
  "amiraku",     // ami + miracle hybrid
  "amitaro",     // name-style blend
  "amimoto",     // Japanese: fisherman, also poetic
  "amitski",     // Slavic-sounding variation
  "amireki",     // fantasy-styled invention
  "amileaf",     // nature + friend
  "amiredo",     // do re mi (mi re do) + ami
  "amido",       // play on “do mi” + ami
  "amidori",     // ami + midori (green in Japanese)
  "amiris",      // ami + iris (light/sight/flower)
  "amixura",     // mix + aura + friend
  "amistre",     // ami + maestro
  "amivox",      // ami + voice
  "amistra",     // ami + orchestra
  "amisol",      // ami + sol (sun or note)
  "amitune",     // tune + ami
  "amiglow",     // glow + friend
  "amirise",     // rise + friend
  "amishade",    // ami + soft light
  "amindra",     // ami + Indra
  "amisia",      // fantasy soft brand
  // Arabic
  "أمي",
  "أمينة",
  "أمير",

  // Hebrew
  "עָמִי",
  "עָמִירָם",

  // Devanagari (Sanskrit / Hindi)
  "अमि",
  "अमित्र",
  "अमिता",

  // Japanese (Katakana / Kanji)
  "アミ",
  "亜美",
  "網",

  // Korean (Hangul)
  "아미",
  "아민",

  // Chinese (Simplified / Traditional overlap)
  "阿米",
  "阿美族",
  "艾米",

  // Russian (Cyrillic)
  "Ами",
  "Амина",
  "Амир",

  // Thai
  "อามิ",
  "อมินา",

  // Ugaritic (Ancient syllabary, stylized/constructed)
  "𐎀𐎎𐎊"
]







export let cntMaxLeds = null; //variables and functions cannot share the same name
countMaxLeds();
export async function countMaxLeds() {
  const Response = await fetch("/api/get_config/num_leds_on_strip");
  const Data = await Response.json(); //.json streams response's body's content, so we still need to await
  if (Data.success) cntMaxLeds = Data.value;
  else console.error("⚠️failed to get cntMaxLeds");
}

export let isBgrndAnim = false;
export function updateIsBgrndAnim(New_Status) {
  isBgrndAnim = New_Status; //update value globally
}

export let cntClick = 0; //is invisible at start; when 0 is the only time icons visible; will increment w every press of the animated keys
export function updateCountClick(New_Count) {
  cntClick = New_Count;
}

export async function getKeysCalibrated() { //returns a true/false whether keys are already calibrated
  const Response = await fetch("/api/get_config/keys_calibrated");
  const Data = await Response.json();
  if (Data.success) return Data.value;
  else console.error("⚠️failed to get keys_calibrated");
}

export const Emojis = `😀😃😄😁😆😅🤣😂🙂🙃😉😊😇🥰😍🤩😘😗😚😙😋😛😜🤪😝🤗🤭🤔🤨😐😑😏😌🤤🥴🤯🤠🥳🥸😎🤓🧐😮😯😲🤡👹👺👻👽👾🤖😺😸😻😼😽💋👋🤚✋🖖👌🤏🤞🤟🤘🤙👈👉👆👍✊👏🙌👐🤲🤝💅🤳💪👂🦻🧠👀👅👄👶🧒👦👧🧑👱👨🧔👨‍🦰👨‍🦱👨‍🦳👨‍🦲👩👩‍🦰🧑‍🦰👩‍🦱🧑‍🦱👩‍🦳🧑‍🦳👩‍🦲🧑‍🦲👱‍♀️👱‍♂️🧓👴👵🙍🙍‍♂️🙍‍♀️🙆🙆‍♂️🙆‍♀️💁💁‍♂️💁‍♀️🙋🙋‍♂️🙋‍♀️🧏🧏‍♂️🧏‍♀️🧑‍⚕️👨‍⚕️👩‍⚕️🧑‍🎓👨‍🎓👩‍🎓🧑‍🏫👨‍🏫👩‍🏫🧑‍🌾👨‍🌾👩‍🌾🧑‍🍳👨‍🍳👩‍🍳🧑‍🔧👨‍🔧👩‍🔧🧑‍🏭👨‍🏭👩‍🏭🧑‍💼👨‍💼👩‍💼🧑‍🔬👨‍🔬👩‍🔬🧑‍💻👨‍💻👩‍💻🧑‍🎤👨‍🎤👩‍🎤🧑‍🎨👨‍🎨👩‍🎨🧑‍✈️👨‍✈️👩‍✈️🧑‍🚀👨‍🚀👩‍🚀🧑‍🚒👨‍🚒👩‍🚒🕵️‍♂️🕵️‍♀️💂💂‍♂️💂‍♀️👷👷‍♂️👷‍♀️🤴👸👳👳‍♂️👳‍♀️👲🧕🤵👰🤰🤱🧑‍🍼👼🎅🤶🦸🦸‍♂️🦸‍♀️🦹🦹‍♂️🦹‍♀️🧙🧙‍♂️🧙‍♀️🧚🧚‍♂️🧚‍♀️🧛🧛‍♂️🧛‍♀️🧜🧜‍♂️🧜‍♀️🧝🧝‍♂️🧝‍♀️🧞🧞‍♂️🧞‍♀️💆💆‍♂️💆‍♀️💇💇‍♂️💇‍♀️🚶🚶‍♂️🚶‍♀️🧍🧍‍♂️🧍‍♀️🏃🏃‍♂️🏃‍♀️💃🕺👯👯‍♂️👯‍♀️🧖🧖‍♂️🧖‍♀️🧘🧳🌂🎃🧵🧶👓🥽🥼🦺👔👕👖🧣🧤🧥🧦👗👘🥻👚👛👜👝🎒👞👟🥾🥿👠👡🩰👢👑👒🎩🎓🧢💄💍💼💫🐵🐒🦍🦧🐶🐕🐩🐺🦊🦝🐱🐈🐈‍⬛🦁🐯🐅🐆🐴🐎🦄🦓🦌🦬🐮🐂🐃🐄🐷🐖🐗🐽🐏🐑🐐🐪🐫🦙🦒🐘🦣🦏🦛🐭🐁🐀🐹🐰🐇🦫🦔🦇🐻🐻‍❄️🐨🐼🦥🦦🦨🦘🦡🐾🦃🐔🐓🐣🐤🐥🐦🐧🦅🦆🦢🦉🦤🪶🦩🦚🦜🐸🐊🐢🦎🐍🐲🐉🦕🦖🐳🐋🐬🦭🐟🐠🐡🦈🐙🐚🐌🦋🐛🐜🐝🪲🐞🦗💐🌸💮🌹🌺🌻🌼🌷🌱🌲🌳🌴🌵🌾🌿🍀🍁🍂🍃🍄🌰🦀🦞🦐🦑🌍🌎🌏🌐🌑🌒🌓🌔🌕🌖🌗🌘🌙🌚🌛🌜🌝🌞⭐🌟🌠⛅🌈⚡⛄🔥💧🌊🎄✨🎋🎍🍇🍈🍉🍊🍋🍌🍍🥭🍎🍏🍐🍑🍒🍓🫐🥝🍅🫒🥥🥑🍆🥔🥕🌽🫑🥒🥬🥦🧄🧅🍄🥜🌰🍞🥐🥖🫓🥨🥯🥞🧇🧀🍔🍟🍕🌭🥪🌮🌯🫔🥙🧆🥚🍳🥘🍲🫕🥣🥗🍿🧈🧂🥫🍱🍘🍙🍚🍛🍜🍝🍠🍢🍣🍤🍥🥮🍡🥟🥠🥡🦪🍦🍧🍨🍩🍪🎂🍰🧁🥧🍫🍬🍭🍮🍯🍼🥛☕🫖🍵🍶🍾🍷🍸🍹🍺🍻🥂🥃🥤🧋🧃🧉🧊🥢🍴🥄🧗🧗‍♂️🧗‍♀️🤺🏇🏂🏌️‍♂️🏌️‍♀️🏄🏄‍♂️🏄‍♀️🚣🚣‍♂️🚣‍♀️🏊🏊‍♂️🏊‍♀️⛹️‍♂️⛹️‍♀️🏋️‍♂️🏋️‍♀️🚴🚴‍♂️🚴‍♀️🚵🚵‍♂️🚵‍♀️🤸🤸‍♂️🤸‍♀️🤼🤼‍♂️🤼‍♀️🤽🤽‍♂️🤽‍♀️🤾🤾‍♂️🤾‍♀️🤹🤹‍♂️🤹‍♀️🧘🧘‍♂️🧘‍♀️🎪🛹🛶🎫🏆🏅🥇⚽⚾🥎🏀🏐🏈🏉🎾🥏🎳🏏🏑🏒🥍🏓🏸🥊🥋🥅⛳⛸🎣🎽🎿🛷🥌🎯🎱🎮🎲🧩🎭🎨🧵🧶🎼🎤🎧🎷🪗🎸🎺🎻🥁🪘🎬🚣🗾🌋🗻🏠🏡🏢🏣🏤🏥🏦🏨🏩🏪🏫🏬🏭🏯🏰💒🗼🗽⛲⛺🌁🌃🌄🌅🌆🌇🌉🎠🎡🎢🚂🚃🚄🚅🚆🚇🚈🚉🚊🚝🚞🚋🚌🚍🚎🚐🚕🚖🚗🚘🚙🚚🚛🚜🛵🛺🚲🛴🚏⛽🚨🚥🚦🚧⚓⛵🚤🚢🛫🛬🪂💺🚁🚟🚠🚡🚀🛸🪐🌠🌌🎆🎇🎑🗿💌🏺🗺🧭💈🧳⌛⏳⌚⏰🧨🎈🎉🎊🎎🎏🎐🧧🎀🎁🤿🪀🪁🔮🧿🧸🪆🧵🪡🧶📿💎📯📻🪕📱📟📠🔋🔌💻💽💾💿📀🧮🎥📺📷📸📹📼🔍🔎💡🔦🏮🪔📔📕📖📗📘📙📚📓📒📃📜📄📰📑🔖🪙🧾📧📨📦📫📪📬📭📮📝📁📂📅📆📇📈📊📋📌📍🔒🔓🔏🔐🔑🔨⛏🪚🔧🪛🔩🦯🔗🪝🧰🧲🪜🧪🧬🔬🔭📡🩺🚪🪟🪞🪑🧺🧼🪥🧯🛒🗿💘💝💖💗💓💞💕💟🧡💛💚💙💜🤎🤍💯💬👁️‍💭💮💈🕛🕧🕐🕜🕑🕝🕒🕞🕓🕟🕔🕠🕕🕡🕖🕢🕗🕣🕘🕤🕙🕥🕚🕦🌀🃏🀄🎴🔈🔉🔊📢📣📯🔔🎵🎶🚭🚯🔃🔄🔀🔁🔂⏩⏪🔼⏫🎦🔅🔆🔱🔰✅#️⃣🔠🔡🔢🔣🔤🆒🆗🆙`;

/* everyemoji 🦫🦊🦝🦘🥮🦁🧁🎆💐🌱🌷🐠↩️🐈🦍🥧🦅🐇🦠🧾🐉🦃🐕 🍃 🍄 🌰 🦀 ↪️ 🐅 🐟 🦭 👆 👇🐎🐈‍⬛🪱🥀🪰🦂🕸🦡🐾🙉🦈 🐙 🐚 🐌 🦋 🐜🌳 🌴 🌵   🦞 🦐  🌏 🌑 🌒 🌔 🌖 🌗 🌘 🌙 🌚 🌛 🌜 ☀ 🌝 🌞 ⭐ 🌟 🌠 ⛅ ⛈ 🌤 🌥 🌦 🌧 🌨 🌩 🌪 🌫 🌬 🌈 ☂ ☔ ⚡ ❄ ☃ ⛄ ☄ 🔥 💧 🌊 🎄 ✨ 🎋 🎍  */
// console.log(`: ${}`);

export const KEYS_BLK = document.querySelectorAll(".key.black");

// export const ARR_ICONS = Array.from(document.querySelectorAll(".icon")); //nodelist -> array
export const TEXT_DYNAMIC = document.getElementById("text-dynamic");

export let control, abortSignal; //to get rid of eventlisteners added, otherwise they double-triple up the calls/click
export function getControl() {
  control = new AbortController();
}
export function setSignal() {
  abortSignal = control.signal;
}

export let isListening = false;
export function updateIsListening(newState) {
  console.log("🥪2. updating isListening to: " + newState);

  isListening = newState;
}

export let keyboardFirstKey = 0, keyboardLastKey = 0, keyboardKeyCount = 0;
export let keyboardFirstNote = "x", keyboardLastNote = "x";
export let keyboardFirstOctave = 0, keyboardLastOctave = 0;
export function updateKeyboardFirstKey(keyboardKey) {
  console.log("🍥updating keyboardFirstKey to: " + keyboardKey);

  keyboardFirstKey = keyboardKey;
  keyboardFirstNote = getNoteFromMidi(keyboardFirstKey);
  keyboardFirstOctave = getOctaveFromMidi(keyboardFirstKey);
  //need to save to database
}
export function updateKeyboardLastKey(keyboardKey) {
  console.log("🥄updating keyboardLastKey to: " + keyboardKey);

  keyboardLastKey = keyboardKey;
  keyboardLastNote = getNoteFromMidi(keyboardLastKey);
  keyboardLastOctave = getOctaveFromMidi(keyboardLastKey);
    //need to save to database

}
export function updateKeyCount() {
  console.log("🍍updating updateKeyCount to: " + keyboardLastKey - keyboardFirstKey + 1);

  keyboardKeyCount = keyboardLastKey - keyboardFirstKey + 1;
    //need to save to database

}

export function getNoteFromMidi(keyId) {
  const NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  const note = NOTES[keyId % 12];
  return note;
}
export function getOctaveFromMidi(keyId) {
  const octave = Math.floor(keyId / 12) - 1; // one octave down
  return octave;
}


//keyboard key #: led index
export let mapNotesLeds = { //will eventually take on the format of the database map
  //eventually: "led_index", "r", "g", "b", "time_on", "time_off"
};

export function updateMapNotesLeds(newMap) {
  console.log("🌮updating map...");

  mapNotesLeds = newMap; //need to save to database
}

export function updateMapDatabase(newMap) {
  console.log("🐭updating database...");

  // Loop through the map and send each mapping to the backend
  Object.entries(newMap).forEach(([key, led_index]) => {
    const data = new URLSearchParams();
    data.append("led_index", led_index);
    data.append("r", 0);
    data.append("g", 0);
    data.append("b", 0);
    data.append("time_on", 0);
    data.append("time_off", 0);

    fetch(`/api/set_row/${key}`, { //setting the key:value, midi:index strip
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: data.toString()
    })
      .then(res => res.json())
      .then(result => {
        console.log(`🐘Key ${key} mapped to LED index ${led_index}:`, result);

      })
      .catch(err => {
        console.error(`🦣Error mapping key ${key}:`, err);
      });
  });

  // updateAvgOctaveDistance;;;
}







export let avgLedsPerOctave = 26.571428571428573; //recall that we are using a density of 160 leds/m; 26.571428571428573 is value we determined experimentally; we use this value for the first loop
// export let avgLedsPerSemitone = 2.1882352941176473; //recall that we are using a density of 160 leds/m; 2.1882352941176473 is value we determined experimentally
export let avgLedsPerSemitone = 2.215; //recall that we are using a density of 160 leds/m; 2.215 is value we determined experimentally

//after first confirm: {"21":2,"33":29,"45":56,"57":83,"69":109,"81":135,"93":162,"105":188} //we use user determined value for 2nd+ loops
export function updateAvgOctaveDistance(newDistance) {
  console.log("🦦updating avgOctaveDistance...");



  avgLedsPerOctave = (avgLedsPerOctave + newDistance)/2;
  // console.log("🦦updating avgOctaveDistance...");
}





export async function getMapFromDatabase() {
  console.log(`💮getting map from database...`);

  try {
    const response = await fetch("/api/get_map");
    const data = await response.json();

    // console.log(`🐩data: ${JSON.stringify(data)}`);

    if (data.success) {
      const map = data.mappings;
      console.log("🎹 MIDI → LED Mappings:", map);

      // map.forEach(row => {
      //   console.log(
      //     `MIDI ${row.midi_note} → LED ${row.led_index} | Color: (${row.r}, ${row.g}, ${row.b}) | On: ${row.time_on} | Off: ${row.time_off}`
      //   );
      // });

      return map;
    } else {
      console.error("Failed to fetch mappings");
      return null;
    }
  } catch (err) {
    console.error("API error:", err);
    return null;
  }
}




// function noteToMidi(note) {
//   const match = note.match(/^([A-G]#?)(\d)$/i);
//   if (!match) return null; // Invalid format

//   const [, noteName, octaveStr] = match;
//   const semitone = Note_To_Offset[noteName.toUpperCase()];
//   const octave = parseInt(octaveStr);

//   if (semitone === undefined) return null; // Note doesn't exist

//   const midi = 12 * (octave + 1) + semitone;

//   return midi >= 0 && midi <= 127 ? midi : null; // Ensure it's a valid MIDI note
// }

// function getLedIndexFromNote(midiNote) {
//   const match = data.find(entry => entry.midi_note === midiNote);
//   return match ? match.led_index : null;
// }

export const Scale_Patterns = { //the key names must match the html values, that way the functions to come will work; values in [] should not be 12+
  maj:      [0,2,4,5,7,9,11],   //W W H W W W;     221222
  min_har:  [0,2,3,5,7,8,11],   //W H W W H W+H;   212213
  min_mel:  [0,2,3,5,7,9,11],   //W H W W W W;     212222
  min_nat:  [0,2,3,5,7,8,10],   //W H W W H W;     212212
  // ------------------------------------------------------
  ion:      [0,2,4,5,7,9,11],   //W W H W W W;     221222
  dor:      [0,2,3,5,7,9,10],   //W H W W W H;     212221
  phryg:    [0,1,3,5,7,8,10],   //H W W W H W;     122212
  lyd:      [0,2,4,6,7,9,11],   //W W W H W W;     222122
  mixolyd:  [0,2,4,5,7,9,10],   //W W H W W H;     221221
  aeol:     [0,2,3,5,7,8,10],   //W H W W H W;     212212
  locr:     [0,1,3,5,6,8,10],   //H W W H W W;     122122
  // ------------------------------------------------------
  maj_pent: [0,2,4,7,9],        //W W W+H W;       2232
  min_pent: [0,3,5,7,10],       //W+H W W W+H;     3223
  // ------------------------------------------------------
  maj_blu:  [0,2,3,4,7,9],      //W H H W+H W;     21132
  min_blu:  [0,3,5,6,7,10],     //W+H W H H W+H;   32113      
  // ------------------------------------------------------
  chrom:    [0,1,2,3,4,5,6,7,8,9,10,11], //chromatic is just every key
  // ------------------------------------------------------
  whole:    [0,2,4,6,8,10],     //W W W W W;       22222   
  // ------------------------------------------------------
  dim_hw:   [0,1,3,4,6,7,9,10], //H W H W H W H;   1212121
  dim_wh:   [0,2,3,5,6,8,9,11], //W H W H W H W;   2121212
  // ------------------------------------------------------
  alger:    [0,2,3,5,6,7,8,11], //W H W H H H W+H; 2121113
  arab_a:   [0,2,3,5,6,8,9,11], //W H W H W H W;   2121212
  arab_b:   [0,2,4,5,6,8,10],   //W W H H W W;     221122
  bali:     [0,1,3,7,8],        //H W W+W H;       1241
  byzn:     [0,1,4,5,7,8,11],   //H W+H H W H W+H; 131213
  chin:     [0,4,6,7,11],       //W+W W H W+W;     4214
  chin_2:   [0,2,5,7,9],        //W W+H W W;       2322
  chin_mog: [0,2,4,7,9],        //W W W+H W;       2232
  egypt:    [0,2,5,7,10],       //W W+H W W+H;     2323
  hindu:    [0,2,4,5,7,8,10],   //W W H W H W;     221212
  hiraj:    [0,2,3,7,8],        //W H W+W H;       2141
  hiraj_2:  [0,4,5,9,11],       //W+W H W+W W;     4142
  hung_maj: [0,3,4,6,7,9,10],   //W+H H W H W H;   312121
  hung_min: [0,2,3,7,8,11],     //W H W+W H W+H;   21413
  ichi:     [0,2,4,5,6,7,9,11], //W W H H H W W;   2211122
  iwa:      [0,1,5,6,10],       //H W+W H W+W;     1414
  jap:      [0,1,5,7,10],       //H W+W W W+H;     1423
  kum:      [0,2,3,7,9],        //W H W+W W;       2142
  kum_2:    [0,1,5,7,8],        //H W+W W H;       1421
  mhmmd:    [0,2,3,5,7,8,11],   //W H W W H W+H;   212213
  mog:      [0,2,4,7,9],        //W W W+H W;       2232
  moor:     [0,1,3,4,5,7,8,10,11], //H W H H W H W H; 12112121
  neo:      [0,1,3,5,7,8,11],   //H W W W H W+H;   122213
  neo_maj:  [0,1,3,5,7,9,11],   //H W W W W W;     122222
  neo_min:  [0,1,3,5,7,8,10],   //H W W W H W;     122212
  span:     [0,1,3,4,5,6,8,10], //H W H H H W W;   1211122
  pelog:    [0,1,3,7,8],        //H W W+W H;       1241
  pelog_2:  [0,1,3,7,10],       //H W W+W W+H;     1243
  persi:    [0,1,4,5,6,8,11],   //H W+H H H W W+H; 131123
  purv_tht: [0,1,4,6,7,8,11],   //H W+H W H H W+H; 132113
  todi_tht: [0,1,3,6,7,8,11],   //H W W+H H H W+H; 123113
  // ------------------------------------------------------
  prom:     [0,2,4,6,9,10],     //W W W W+H H;     22231
  prom_neo: [0,1,4,6,9,10],     //H W+H W W+H H;   13231
  // ------------------------------------------------------


  hw: [0,],   //H ;    12
  hw: [0,],   //H ;    12
  hw: [0,],   //H ;    12
  hw: [0,],   //H ;    12
  aug: [0,3,4,7,8,11],          //W+H H W+H H W+H;  31313
  dom_pent: [0,2,4,7,10],       //W W W+H W+H;      2233
};

export const Note_To_Offset = { //each offset is 1 semitone
  "C":0, "C#":1, "D":2, "D#":3, "E":4, "F":5, "F#":6, "G":7, "G#":8, "A":9, "A#":10, "B":11
};

export const Chord_Patterns = {
  // Basic Triads
  maj:     [0, 4, 7],        // Major triad:     Root, Major 3rd, Perfect 5th
  min:     [0, 3, 7],        // Minor triad:     Root, Minor 3rd, Perfect 5th
  dim:     [0, 3, 6],        // Diminished:      Root, Minor 3rd, Diminished 5th
  aug:     [0, 4, 8],        // Augmented:       Root, Major 3rd, Augmented 5th
  sus2:    [0, 2, 7],        // Suspended 2nd:   Root, Major 2nd, Perfect 5th
  sus4:    [0, 5, 7],        // Suspended 4th:   Root, Perfect 4th, Perfect 5th

  // Seventh Chords
  maj7:    [0, 4, 7, 11],    // Major 7th:       Root, Maj3, P5, Maj7
  min7:    [0, 3, 7, 10],    // Minor 7th:       Root, Min3, P5, Min7
  dom7:    [0, 4, 7, 10],    // Dominant 7th:    Root, Maj3, P5, Min7
  dim7:    [0, 3, 6, 9],     // Diminished 7th:  Root, Min3, Dim5, Dim7
  halfdim7:[0, 3, 6, 10],    // Half-dim 7:      Root, Min3, Dim5, Min7
  minmaj7: [0, 3, 7, 11],    // Minor Major 7th: Root, Min3, P5, Maj7
  aug7:    [0, 4, 8, 10],    // Augmented 7th:   Root, Maj3, Aug5, Min7
  augmaj7: [0, 4, 8, 11],    // Augmented Maj7:  Root, Maj3, Aug5, Maj7
  dom7b5:  [0, 4, 6, 10],    // Dominant 7♭5:    Root, Maj3, Dim5, Min7
  dom7b9:  [0, 4, 7, 10, 13],// Dominant 7♭9:    Root, Maj3, P5, Min7, ♭9

  // Extended Chords
  dom9:    [0, 4, 7, 10, 14],// Dominant 9:      Root, Maj3, P5, Min7, Maj9
  maj9:    [0, 4, 7, 11, 14],// Major 9:         Root, Maj3, P5, Maj7, Maj9
  min9:    [0, 3, 7, 10, 14],// Minor 9:         Root, Min3, P5, Min7, Maj9
  dom11:   [0, 4, 7, 10, 14, 17], // Dominant 11: Root, Maj3, P5, Min7, 9, 11
  dom13:   [0, 4, 7, 10, 14, 17, 21], // Dominant 13

  // Added Tone Chords
  add9:    [0, 4, 7, 14],    // Major Add9:      Root, Maj3, P5, Maj9
  minadd9: [0, 3, 7, 14],    // Minor Add9
  add11:   [0, 4, 7, 17],    // Add11
  add13:   [0, 4, 7, 21],    // Add13

  // Power Chord
  power:   [0, 7],           // 5th only:        Root, Perfect 5th

  // Suspended + 7th
  sus2_7:  [0, 2, 7, 10],    // Suspended 2nd + dom7
  sus4_7:  [0, 5, 7, 10],    // Suspended 4th + dom7

  // Jazz & Fusion
  maj7s11: [0, 4, 7, 11, 18],// Maj7 + sharp11
  min11:   [0, 3, 7, 10, 14, 17], // Minor 11th
  dom7s9:  [0, 4, 7, 10, 15],// Dom7 + sharp9
  dom7b9:  [0, 4, 7, 10, 13],// Dom7 + flat9
  dom7s5:  [0, 4, 8, 10],    // Dom7 + sharp5

  // Exotic / Optional
  cluster: [0, 1, 2],        // Tone cluster
  quartal: [0, 5, 10],       // Built on 4ths
};
